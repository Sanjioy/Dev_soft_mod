﻿using System;

namespace Пр6_3_Стынгач
{
    class Figura
    {
        private double param1;
        private double param2;
        private double param3;

        public Figura(double p1)
        {
            param1 = p1;
        }

        public Figura(double p1, double p2)
        {
            param1 = p1;
            param2 = p2;
        }

        public Figura(double p1, double p2, double p3)
        {
            param1 = p1;
            param2 = p2;
            param3 = p3;
        }

        public void ShowArea()
        {
            if (param2 == 0 && param3 == 0)
            {
                Console.WriteLine("Фигура: Квадрат");
                double area = param1 * param1;
                Console.WriteLine("Площадь: " + area);
            }
            else if (param2 != 0 && param3 == 0)
            {
                Console.WriteLine("Фигура: Прямоугольник");
                double area = param1 * param2;
                Console.WriteLine("Площадь: " + area);
            }
            else
            {
                Console.WriteLine("Фигура: Трапеция");
                double area = (param1 + param2) / 2 * param3;
                Console.WriteLine("Площадь: " + area);
            }
        }
    }

    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Введите параметры фигуры:");

            Console.Write("Параметр 1: ");
            double param1 = double.Parse(Console.ReadLine());

            Console.Write("Параметр 2 (если есть): ");
            string param2Input = Console.ReadLine();
            double param2;

            if (param2Input == "")
            {
                Figura f = new Figura(param1);
                f.ShowArea();
            }
            else
            {
                Console.Write("Параметр 3 (если есть): ");
                string param3Input = Console.ReadLine();
                double param3;

                if (param3Input == "")
                {
                    param2 = double.Parse(param2Input);
                    Figura f = new Figura(param1, param2);
                    f.ShowArea();
                }
                else
                {
                    param2 = double.Parse(param2Input);
                    param3 = double.Parse(param3Input);
                    Figura f = new Figura(param1, param2, param3);
                    f.ShowArea();
                }
            }

            Console.ReadKey();
        }
    }
}
