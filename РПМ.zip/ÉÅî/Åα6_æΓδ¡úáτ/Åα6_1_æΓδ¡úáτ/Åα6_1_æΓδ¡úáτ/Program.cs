﻿using System;

namespace Пр6_1_Стынгач
{
    class Program
    {
        static void Perim(int a, int b, int d)
        {
            Console.WriteLine("Периметр треугольника = {0}", a + b + d);
        }

        static void Perim(int a)
        {
            Console.WriteLine("Периметр квадрата = {0}", 4 * a);
        }

        static void Perim(int a, int b)
        {
            Console.WriteLine("Периметр прямоугольника = {0}", 2 * a + 2 * b);
        }

        // Переменное число параметров.
        static void Perim(params int[] ar)
        {
            int p = 0;
            foreach (int x in ar)
                p += x;
            Console.WriteLine("Периметр {0}-угольника = {1}", ar.Length, p);
        }

        static void Main(string[] args)
        {
            Perim(3, 4, 5);
            Perim(5);
            Perim(10, 20);
            Perim(2, 3, 4, 5, 6, 7, 9);
            Console.ReadKey();
        }
    }
}
