﻿using System;

namespace Пр6_2_Стынгач
{
    class Program
    {
        static void Main(string[] args)
        {
            string fam, comfort;
            int size;

            Console.WriteLine("Введите заказы (для завершения введите Q):");

            while (true)
            {
                Console.Write("Фамилия: ");
                fam = Console.ReadLine();

                if (fam == "Q" || fam == "q")
                    break;

                Console.Write("Количество мест: ");
                int.TryParse(Console.ReadLine(), out size);

                Console.Write("Класс: ");
                comfort = Console.ReadLine();

                Zakaz z = new Zakaz(fam, size, comfort);
                z.Show();
            }

            Zakaz z1 = new Zakaz("Иванов", 1, "Люкс");
            z1.Show();
            Zakaz z2 = new Zakaz("Петров", 2);
            z2.Show();
            Zakaz z3 = new Zakaz("Сидоров");
            z3.Show();
            Zakaz z4 = new Zakaz();
            z4.Show();
            Console.ReadKey();

        }
    }
    class Zakaz
    {
        private string fam;
        private int size;
        private string comfort;

        public Zakaz(string fm, int sz, string cmf)
        {
            fam = fm;
            size = sz;
            comfort = cmf;
        }

        public Zakaz(string fm, int sz)
        {
            fam = fm;
            size = sz;
            comfort = "Стандарт";
        }

        public Zakaz(string fm)
        {
            fam = fm;
            size = 3;
            comfort = "Стандарт";
        }

        public Zakaz()
        {
            fam = "Неизвестный";
            size = 6;
            comfort = "Хостел";
        }

        public void Show()
        {
            Console.WriteLine("{0} забронировал {1} местный номер класса {2}",
                                    fam, size, comfort);
        }
    }
}
