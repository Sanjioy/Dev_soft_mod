﻿using System;

namespace Пр6_4_Стынгач
{
    class Tour
    {
        public void TourCalc()
        {
            Console.WriteLine("Выбран тур: Минское море. Стоимость: бесплатно");
        }

        public void TourCalc(string country)
        {
            Console.WriteLine($"Выбран тур: {country}. Стоимость на 1 день: 900 рублей");
        }

        public void TourCalc(string country, int numberOfDays)
        {
            int totalCost = 900 * numberOfDays;
            Console.WriteLine($"Выбран тур: {country}. Стоимость на {numberOfDays} дней/дня: {totalCost} рублей");
        }
    }

    class Program
    {
        static void Main()
        {
            Tour tour = new Tour();

            Console.WriteLine("Введите параметры тура (например: Франция 5):");

            string[] inputParams = Console.ReadLine().Split(' ');

            if (inputParams.Length == 1 && inputParams[0] == "")
            {
                tour.TourCalc();
            }
            else if (inputParams.Length == 1)
            {
                tour.TourCalc(inputParams[0]);
            }
            else if (inputParams.Length == 2 && int.TryParse(inputParams[1], out int numberOfDays))
            {
                tour.TourCalc(inputParams[0], numberOfDays);
            }
            else
            {
                Console.WriteLine("Некорректный ввод параметров.");
            }
        }
    }
}