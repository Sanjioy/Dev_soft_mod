﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Пр8_1_Стынгач
{
    class Netbook : Notebook
    {
        private int mas;

        public int Mas
        {
            get
            {
                return mas;
            }
            set
            {
                mas = (value < 30) ? 10 : value;
            }
        }

        public Netbook(string model, int ram, int time, int mas) : base(model, ram, time)
        {
            this.Mas = mas;
        }
        //создадим новый метод Start класса-наследника с модификатором override
        public override void Start()
        {
            Console.WriteLine("{0} весит {1} кг", Model, Mas);
        }
    }
}
