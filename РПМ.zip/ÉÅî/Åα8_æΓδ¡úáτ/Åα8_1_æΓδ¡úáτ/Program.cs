﻿using System;

namespace Пр8_1_Стынгач
{
    class Program
    {
        static void Main(string[] args)
        {
            Notebook nb = new Notebook("Asus", 1024, 120);
            nb.Start();
            nb.End();
            Computer comp2 = new Notebook("Dell", 4096, 30);
            comp2.Start();
            comp2.End();
            Netbook netb1 = new Netbook("HP", 4096, 120, 20);
            netb1.Start();
            netb1.End();
            Console.ReadKey();

        }
    }
}