﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;

namespace Пр8_1_Стынгач
{
    class Notebook : Computer
    {
        private int time;
        public int Time
        {
            get
            {
                return time;
            }
            set
            {
                time = (value < 10) ? 15 : value;
            }
        }
        public Notebook()
        {
        }

        public Notebook(string model, int ram, int time) : base(model, ram)
        {
            this.Time = time;
        }

        public override void End()
        {
            Console.WriteLine("{0} выключается, заряд {1} мин", Model, Time);
        }
    }
}
