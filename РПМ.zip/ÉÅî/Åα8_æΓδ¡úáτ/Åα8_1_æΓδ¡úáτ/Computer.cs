﻿using System;

namespace Пр8_1_Стынгач
{
    class Computer
    {
        private string model;
        private int ram;
        public string Model
        {
            get
            {
                return model;
            }
            set
            {
                model = (value != "") ? value : "noName";
            }
        }
        public int Ram
        {
            get
            {
                return ram;
            }
            set
            {
                ram = (value < 500) ? 640 : value;
            }
        }
        public Computer()
        {
        }
        public Computer(string model, int ram)
        {
            this.Model = model;
            this.Ram = ram;
        }
        public virtual void Start()
        {
            Console.WriteLine("{0} работает, память = {1}", Model, Ram);
        }
        public virtual void End()
        {
            Console.WriteLine("{0} выключается", Model);
        }
    }
}