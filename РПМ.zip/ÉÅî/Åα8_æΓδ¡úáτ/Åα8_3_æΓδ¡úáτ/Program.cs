﻿using System;

namespace Пр8_3_Стынгач
{
    class Animal
    {
        public string Name
        {
            get; set;
        }
        public double Weight
        {
            get; set;
        }
        public string Color
        {
            get; set;
        }

        public virtual void Run()
        {
            Console.WriteLine($"{Name} бежит.");
        }

        public virtual void Sleep()
        {
            Console.WriteLine($"{Name} спит.");
        }

        public virtual void Golos()
        {
            Console.WriteLine("Животное издает звук.");
        }
    }

    class Cat : Animal
    {
        public override void Golos()
        {
            Console.WriteLine($"{Name} мяукает: 'Мяу-мяу'.");
        }
    }

    class Dog : Animal
    {
        public override void Golos()
        {
            Console.WriteLine($"{Name} лает: 'Гав-гав'.");
        }
    }

    class Program
    {
        static void Main()
        {
            Cat cat = new Cat { Name = "Кот", Weight = 5.2, Color = "Серый" };
            Dog dog = new Dog { Name = "Собака", Weight = 12.7, Color = "Рыжий" };

            Console.WriteLine($"Имя: {cat.Name}, Вес: {cat.Weight}, Цвет: {cat.Color}");
            cat.Run();
            cat.Sleep();
            cat.Golos();

            Console.WriteLine();

            Console.WriteLine($"Имя: {dog.Name}, Вес: {dog.Weight}, Цвет: {dog.Color}");
            dog.Run();
            dog.Sleep();
            dog.Golos();
        }
    }
}

