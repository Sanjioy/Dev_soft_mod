﻿using System;

namespace Пр8_2_Стынач
{
    class Transport
    {
        public string Model
        { get; set; }
        public int Speed
        { get; set; }
        public double Mass
        { get; set; }

        public void Start()
        {
            Console.WriteLine("Транспорт начал движение.");
        }

        public void Stop()
        {
            Console.WriteLine("Транспорт остановился.");
        }

        public void ShowInfo()
        {
            Console.WriteLine("{0} модель", Model);
            Console.WriteLine("Скорость {0} км/ч ", Speed);
            Console.WriteLine("Масса {0} кг", Mass);
        }
    }

    class Avto : Transport
    {
        public Avto(string model, int speed, double mass)
        {
            Model = model;
            Speed = speed;
            Mass = mass;
        }
    }

    class Moto : Transport
    {
        public Moto(string model, int speed, double mass)
        {
            Model = model;
            Speed = speed;
            Mass = mass;
        }
    }

    class Velo : Transport
    {
        public Velo(string model, int speed, double mass)
        {
            Model = model;
            Speed = speed;
            Mass = mass;
        }
    }

    class Program
    {
        static void Main()
        {
            Avto car = new Avto("Легковой автомобиль", 120, 1500);
            Moto motorcycle = new Moto("Мотоцикл", 180, 250);
            Velo bicycle = new Velo("Велосипед", 20, 10);

            Console.WriteLine("Информация об автомобиле:");
            car.ShowInfo();
            car.Start();
            car.Stop();

            Console.WriteLine("\nИнформация о мотоцикле:");
            motorcycle.ShowInfo();
            motorcycle.Start();
            motorcycle.Stop();

            Console.WriteLine("\nИнформация о велосипеде:");
            bicycle.ShowInfo();
            bicycle.Start();
            bicycle.Stop();
        }
    }
}