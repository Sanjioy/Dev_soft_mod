﻿using System;

namespace Пр8_4_Стынгач
{
    class Tovar
    {
        public string Name
        {
            get; set;
        }
        public double Price
        {
            get; set;
        }

        public virtual void Calc()
        {
            Console.WriteLine($"Стоимость {Name}: {Price}");
        }
    }

    class Book : Tovar
    {
        public int Kvo
        {
            get; set;
        }

        public override void Calc()
        {
            double totalPrice = Price * Kvo;
            Console.WriteLine($"Общая стоимость книг ({Kvo} шт.): {totalPrice}");
        }
    }

    class Pen : Tovar
    {
        public int Kvo
        {
            get; set;
        }

        public override void Calc()
        {
            double totalPrice = Price * Kvo;
            Console.WriteLine($"Общая стоимость ручек ({Kvo} шт.): {totalPrice}");
        }
    }

    class Candy : Tovar
    {
        public double Weight
        {
            get; set;
        }

        public override void Calc()
        {
            double totalPrice = Price * Weight;
            Console.WriteLine($"Общая стоимость конфет ({Weight} кг): {totalPrice}");
        }
    }

    class Program
    {
        static void Main()
        {
            Book book = new Book { Name = "Книга", Price = 15.5, Kvo = 10 };
            Pen pen = new Pen { Name = "Ручка", Price = 2.0, Kvo = 50 };
            Candy candy = new Candy { Name = "Конфеты", Price = 10.0, Weight = 2.5 };

            book.Calc();
            pen.Calc();
            candy.Calc();
        }
    }
}

