﻿using System;
using System.Collections;

namespace Пр11_2_Стынгач
{
    // Структура, содержащая информацию о сотруднике.
    public struct Work
    {
        public string kod;
        public string fullName;
        public string position;
        public uint salary;
        public int experience;
    }

    class Program
    {       
        // Инициализация списка сотрудников.
        static void InitializeEmployees(ArrayList employees)
        {
            employees.Add(new Work { kod = "АИ001", fullName = "Сидоров Иван", position = "повар", salary = 25000, experience = 3 });
            employees.Add(new Work { kod = "АП002", fullName = "Андреев Петр", position = "кондитер", salary = 15842, experience = 2 });
            employees.Add(new Work { kod = "ИИ001", fullName = "Иванова Ирина", position = "пекарь", salary = 47852, experience = 4 });
            employees.Add(new Work { kod = "ВО001", fullName = "Выходова Ольга", position = "тестомес", salary = 25871, experience = 1 });
            employees.Add(new Work { kod = "ЮЯ001", fullName = "Юрин Ян", position = "кондитер", salary = 35890, experience = 5 });
        }

        // Отображение списка сотрудников.
        static void DisplayEmployees(ArrayList employees)
        {
            Console.WriteLine("\nТекущий список сотрудников:\n");

            foreach (Work employee in employees)
            {
                Console.WriteLine($"{employee.kod} {employee.fullName} {employee.position} {employee.salary.ToString("C")} {employee.experience}");
            }
        }

        // Добавление нового сотрудника.
        static void AddEmployee(ArrayList employees)
        {
            Console.Write("\nВведите код сотрудника: ");
            string kod = Console.ReadLine();

            Console.Write("Введите Ф.И.: ");
            string fullName = Console.ReadLine();

            Console.Write("Введите должность: ");
            string position = Console.ReadLine();

            Console.Write("Введите оклад: ");
            uint salary = Convert.ToUInt32(Console.ReadLine());

            Console.Write("Введите стаж: ");
            int experience = Convert.ToInt32(Console.ReadLine());

            employees.Add(new Work { kod = kod, fullName = fullName, position = position, salary = salary, experience = experience });

            Console.WriteLine("Сотрудник успешно добавлен.");
        }

        // Удаление сотрудника.
        static void RemoveEmployee(ArrayList employees)
        {
            Console.Write("\nВведите код увольняемого сотрудника: ");
            string kod = Console.ReadLine();

            int index = FindEmployeeIndexByCode(employees, kod);

            if (index != -1)
            {
                Console.WriteLine($"\nУволенный сотрудник: {((Work)employees[index]).fullName}\n");
                employees.RemoveAt(index);
            }
            else
            {
                Console.WriteLine("Сотрудник с таким кодом не найден.");
            }
        }

        // Подсчет сотрудников по должности.
        static void CountEmployeesByPosition(ArrayList employees)
        {
            Console.Write("\nВведите должность для подсчета: ");
            string position = Console.ReadLine();

            int count = 0;

            foreach (Work employee in employees)
            {
                if (employee.position.Equals(position, StringComparison.OrdinalIgnoreCase))
                {
                    count++;
                }
            }

            Console.WriteLine($"Количество сотрудников на должности {position}: {count}");
        }

        // Отображение списка сотрудников в обратном порядке.
        static void DisplayEmployeesReversed(ArrayList employees)
        {
            Console.WriteLine("\nСписок сотрудников в обратном порядке:");

            for (int i = employees.Count - 1; i >= 0; i--)
            {
                Console.WriteLine($"{((Work)employees[i]).kod} {((Work)employees[i]).fullName} " +
                                  $"{((Work)employees[i]).position} {((Work)employees[i]).salary} {((Work)employees[i]).experience}");
            }
        }

        // Отображение сотрудников со стажем менее 5 лет и окладом выше среднего.
        static void DisplayHighSalaryLowExperienceEmployees(ArrayList employees)
        {
            double averageSalary = CalculateAverageSalary(employees);

            Console.WriteLine($"\nСотрудники со стажем менее 5 лет и окладом выше среднего ({averageSalary.ToString("C")}):");

            foreach (Work employee in employees)
            {
                if (employee.experience < 5 && employee.salary > averageSalary)
                {
                    Console.WriteLine($"{employee.fullName} {employee.salary.ToString("C")} {employee.experience} лет");
                }
            }
        }

        // Вычисление среднего оклада среди сотрудников.
        static double CalculateAverageSalary(ArrayList employees)
        {
            double totalSalary = 0;

            foreach (Work employee in employees)
            {
                totalSalary += employee.salary;
            }

            return totalSalary / employees.Count;
        }

        // Поиск индекса сотрудника по коду.
        static int FindEmployeeIndexByCode(ArrayList employees, string code)
        {
            for (int i = 0; i < employees.Count; i++)
            {
                if (((Work)employees[i]).kod.Equals(code, StringComparison.OrdinalIgnoreCase))
                {
                    return i;
                }
            }
            return -1;
        }

        // Отображение меню для пользователя.
        static void ShowMenu()
        {
            Console.WriteLine("\nВыберите действие:");
            Console.WriteLine("1. Добавить запись");
            Console.WriteLine("2. Удалить запись");
            Console.WriteLine("3. Найти количество сотрудников по должности");
            Console.WriteLine("4. Вывести данные в обратном порядке");
            Console.WriteLine("5. Найти и вывести сотрудников со стажем менее 5 лет и окладом выше среднего");
            Console.WriteLine("6. Выйти из программы");
            Console.WriteLine();
            Console.WriteLine("Введите номер действия:");
        }

        // Основной метод.
        static void Main()
        {
            // Для корректного отображения информации.
            Console.OutputEncoding = System.Text.Encoding.UTF8;

            // Создание списка сотрудников.
            ArrayList employees = new ArrayList();

            // Инициализация начальных данных.
            InitializeEmployees(employees);

            // Вывод начального списка сотрудников.
            DisplayEmployees(employees);

            while (true)
            {
                // Отображение меню действий для пользователя.
                ShowMenu();

                // Получение выбора пользователя.
                string choice = Console.ReadLine();

                switch (choice)
                {
                    case "1":
                        AddEmployee(employees);
                        DisplayEmployees(employees);
                        break;

                    case "2":
                        RemoveEmployee(employees);
                        DisplayEmployees(employees);
                        break;

                    case "3":
                        CountEmployeesByPosition(employees);
                        break;

                    case "4":
                        DisplayEmployeesReversed(employees);
                        break;

                    case "5":
                        DisplayHighSalaryLowExperienceEmployees(employees);
                        break;

                    case "6":
                        Console.WriteLine("Программа завершена.");
                        return;

                    default:
                        Console.WriteLine("Некорректный выбор. Пожалуйста, повторите.");
                        break;
                }
            }
        }
    }
}
