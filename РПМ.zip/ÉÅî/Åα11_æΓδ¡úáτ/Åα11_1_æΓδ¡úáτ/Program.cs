﻿using System;
using System.Linq;
using System.Text.RegularExpressions;

namespace Пр11_1_Стынгач
{
    public struct Employee
    {
        public int EmployeeCode;
        public double Salary;
        public string Name;
        public string Surname;
        public string CardNumber;
        public string PhoneNumber;
    }

    class Program
    {
        // Перечисления для имени и фамилии
        enum Name
        {
            Иван, Петр, Ирина, Ольга, Ян
        }
        enum Surname
        {
            Сидоров, Андреев, Иванова, Выходова, Юрин
        }

        static void Main(string[] args)
        {
            Random random = new Random();
            // Создание массива сотрудников
            Employee[] employees = new Employee[Enum.GetValues(typeof(Surname)).Length];

            // Получение значений из перечислений
            Name[] names = Enum.GetValues(typeof(Name)).Cast<Name>().ToArray();
            Surname[] surnames = Enum.GetValues(typeof(Surname)).Cast<Surname>().ToArray();

            // Заполнение информации о сотрудниках
            for (int i = 0; i < employees.Length; i++)
            {
                employees[i].EmployeeCode = i;

                if (i < names.Length && i < surnames.Length)
                {
                    // Имя и фамилия сотрудника
                    employees[i].Name = names[i].ToString();
                    employees[i].Surname = surnames[i].ToString();
                }

                // Генерация случайной зарплаты
                employees[i].Salary = random.Next(200000, 300000) / 10.0;

                // Ввод номера карты и номера телефона сотрудника
                Console.WriteLine($"Cотрудник № {i + 1}");
                Console.Write("Номер карты: ");
                employees[i].CardNumber = Console.ReadLine();
                Console.Write("Номер телефона: ");
                employees[i].PhoneNumber = Console.ReadLine();
            }

            // Вывод информации о сотрудниках
            Console.WriteLine("\nРезультат:");
            foreach (var employee in employees)
            {
                Console.WriteLine($"Cотрудник № {employee.EmployeeCode + 1}: {employee.Name} {employee.Surname}, " +
                    $"Зарплата - {employee.Salary}, Номер карты - {employee.CardNumber}, Номер телефона - {employee.PhoneNumber}");
            }

            // Проверка введенной информации
            Console.WriteLine("\nПроверка корректности ввода:");
            foreach (var employee in employees)
            {
                ValidateCardNumber(employee.CardNumber);
                ValidatePhoneNumber(employee.PhoneNumber);
            }

            // Подсчет сотрудников с зарплатой выше 20000
            Console.WriteLine("\nКоличество сотрудников с зарплатой больше 20000 рублей: " +
                employees.Count(emp => emp.Salary > 20000));

            // Вывод фамилий сотрудников, начинающихся на 'А'
            Console.WriteLine("\nФамилии сотрудников, начинающихся на А:");
            foreach (var employee in employees.Where(emp => emp.Surname != null && emp.Surname.StartsWith("А")))
            {
                Console.WriteLine(employee.Surname);
            }

            // Вывод отсортированных фамилий
            Console.WriteLine("\nСписок фамилий, отсортированных по алфавиту:");
            foreach (var employee in employees.OrderBy(emp => emp.Surname))
            {
                Console.WriteLine(employee.Surname);
            }

            Console.ReadKey();
        }

        // Проверка номера карты
        static void ValidateCardNumber(string cardNumber)
        {
            // Формат "XXXX-XXXX-XXXX-XXXX".
            string pattern = @"^\d{4}-\d{4}-\d{4}-\d{4}$";

            if (Regex.IsMatch(cardNumber, pattern))
            {
                Console.WriteLine($"Номер карты введен корректно: {cardNumber}");
            }
            else
            {
                Console.WriteLine($"Некорректный номер карты: {cardNumber}");
            }
        }

        // Проверка номера телефона
        static void ValidatePhoneNumber(string phoneNumber)
        {
            // Формат "XXX-XX-XX".
            string pattern = @"^\d{3}-\d{2}-\d{2}$";

            if (Regex.IsMatch(phoneNumber, pattern))
            {
                Console.WriteLine($"Номер телефона введен корректно: {phoneNumber}");
            }
            else
            {
                Console.WriteLine($"Некорректный номер телефона: {phoneNumber}");
            }
        }
    }
}
