﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Экзамен_аналог2
{
    public partial class Form1 : Form
    {
        private string selectedPersonType = "";
        private Label lblResult;

        public Form1()
        {
            InitializeComponent();
            InitializePaymentDetails();
            InitializeResultLabel();

            // Подписка на события нажатия кнопок.
            btnSend.Click += btnSend_Click;
            btnCancel.Click += btnCancel_Click;

            // Подписка на события выбора радиокнопок.
            rbtnLegalPerson.CheckedChanged += rbtnLegalPerson_CheckedChanged;
            rbtnBusinessman.CheckedChanged += rbtnBusinessman_CheckedChanged;
        }

        // Генерация случайного номера.
        private int GenerateRandomNumber()
        {
            Random rand = new Random();
            return rand.Next(100000, 999999);
        }

        // Метод инициализации деталей платежа.
        private void InitializePaymentDetails()
        {
            // Номер и дата поручения (автоматические).
            txtNumber.Text = GenerateRandomNumber().ToString();
            txtDate.Text = DateTime.Today.ToShortDateString();

            // Заполнение комбо-боксов.
            cmbPayerBank.Items.AddRange(new string[] { "ПАО «Лучший банк»", "ПАО «Главный банк»", "ПАО «Замечательный банк»" });
            cmbReceiverBank.Items.AddRange(new string[] { "ПАО «Лучший банк»", "ПАО «Главный банк»", "ПАО «Замечательный банк»" });
        }

        // Метод для установки валидации ИНН с заданной длиной.
        private void SetINNValidation(int requiredLength)
        {
            txtINN.MaxLength = requiredLength;
            if (txtINN.Text.Length > requiredLength)
            {
                txtINN.Text = txtINN.Text.Substring(0, requiredLength);
            }
        }

        // Обработчик события изменения выбора радиокнопки "Юрлицо".
        private void rbtnLegalPerson_CheckedChanged(object sender, EventArgs e)
        {
            selectedPersonType = "Юрлицо";
            int requiredLength = 10;
            SetINNValidation(requiredLength);
        }

        // Обработчик события изменения выбора радиокнопки "Предприниматель".
        private void rbtnBusinessman_CheckedChanged(object sender, EventArgs e)
        {
            selectedPersonType = "Предприниматель";
            int requiredLength = 12;
            SetINNValidation(requiredLength);
        }

        // Метод для проверки валидности номера счета получателя.
        private bool IsPayeeAccountValid()
        {
            return !string.IsNullOrWhiteSpace(txtReceiverAccount.Text) && txtReceiverAccount.Text.Length >= 20;
        }

        // Метод для проверки валидности БИК.
        private bool IsBIKValid()
        {
            return !string.IsNullOrWhiteSpace(txtBIC.Text) && txtBIC.Text.Length >= 9;
        }

        // Метод для проверки валидности ИНН.
        private bool IsINNValid()
        {
            if (rbtnLegalPerson.Checked)
            {
                return !string.IsNullOrWhiteSpace(txtINN.Text) && txtINN.Text.Length == 10;
            }
            else if (rbtnBusinessman.Checked)
            {
                return !string.IsNullOrWhiteSpace(txtINN.Text) && txtINN.Text.Length == 12;
            }

            return false;
        }

        // Метод для проверки заполнения всех обязательных полей.
        private bool AreAllFieldsFilled()
        {
            return !string.IsNullOrWhiteSpace(txtNumber.Text) &&
                   !string.IsNullOrWhiteSpace(txtPayer.Text) &&
                   !string.IsNullOrWhiteSpace(txtAmount.Text) &&
                   !string.IsNullOrWhiteSpace(cmbPayerBank.Text) &&
                   !string.IsNullOrWhiteSpace(txtBIC.Text) &&
                   !string.IsNullOrWhiteSpace(txtINN.Text) &&
                   !string.IsNullOrWhiteSpace(cmbReceiverBank.Text) &&
                   !string.IsNullOrWhiteSpace(txtReceiverAccount.Text);
        }

        // Метод для отправки платежного поручения.
        private void btnSend_Click(object sender, EventArgs e)
        {
            if (AreAllFieldsFilled())
            {
                bool isBIKValid = IsBIKValid();
                bool isINNValid = IsINNValid();
                bool isPayeeAccountValid = IsPayeeAccountValid();

                if (isBIKValid && isINNValid && isPayeeAccountValid)
                {
                    if (MessageBox.Show("Вы уверены, что хотите отправить платежное поручение?", "Подтверждение", MessageBoxButtons.YesNo) == DialogResult.Yes)
                    {
                        DisableInputFields();
                        ShowResult();
                    }
                }
                else
                {
                    if (!isBIKValid)
                    {
                        MessageBox.Show("Пожалуйста, введите действительный БИК, содержащий не менее 9 цифр", "Ошибка БИК", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }

                    if (!isINNValid)
                    {
                        if (rbtnLegalPerson.Checked)
                        {
                            MessageBox.Show("Пожалуйста, введите действительный ИНН юридического лица из 10 цифр.", "Ошибка ИНН", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        }
                        else if (rbtnBusinessman.Checked)
                        {
                            MessageBox.Show("Пожалуйста, введите действительный ИНН предпринимателя из 12 цифр.", "Ошибка ИНН", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        }
                    }

                    if (!isPayeeAccountValid)
                    {
                        MessageBox.Show("Пожалуйста, введите действительный счет получателя платежа, содержащий не менее 20 цифр.", "Ошибка счета получателя платежа", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
            }
            else
            {
                MessageBox.Show("Пожалуйста, заполните все обязательные поля.", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        // Очистка полей для заполнения.
        private void ClearFields()
        {
            txtPayer.Clear();
            txtAmount.Clear();
            cmbPayerBank.SelectedIndex = -1;
            txtBIC.Clear();
            txtINN.Clear();
            cmbReceiverBank.SelectedIndex = -1;
            txtReceiverAccount.Clear();

            // Разблокировка полей.
            txtPayer.Enabled = true;
            txtAmount.Enabled = true;
            cmbPayerBank.Enabled = true;
            txtBIC.Enabled = true;
            txtINN.Enabled = true;
            rbtnLegalPerson.Enabled = true;
            rbtnBusinessman.Enabled = true;
            cmbReceiverBank.Enabled = true;
            txtReceiverAccount.Enabled = true;
        }

        // Метод для отмены заполнения полей.
        private void btnCancel_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Вы уверены, что хотите отменить заполнение?", "Отменить", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {
                ClearFields();
            }
        }

        // Блокировка всех полей после отправки.
        private void DisableInputFields()
        {
            txtPayer.Enabled = false;
            txtAmount.Enabled = false;
            cmbPayerBank.Enabled = false;
            txtBIC.Enabled = false;
            txtINN.Enabled = false;
            rbtnLegalPerson.Enabled = false;
            rbtnBusinessman.Enabled = false;
            cmbReceiverBank.Enabled = false;
            txtReceiverAccount.Enabled = false;
        }

        private void InitializeResultLabel()
        {
            lblResult = new Label();
            lblResult.AutoSize = true;
            // Расположение под кнопками "Отправить" и "Отменить".
            lblResult.Location = new Point(10, btnSend.Location.Y + 50);
            lblResult.Text = "";
            this.Controls.Add(lblResult);
        }

        // Метод для отображения результата успешной отправки данных.
        private void ShowResult()
        {

            string result = $"Платежное поручение принято к исполнению.\n\n" +
                $"Номер: {txtNumber.Text}\n" +
                $"Дата: {txtDate.Text}\n" +
                $"Плательщик: {txtPayer.Text}\n" +
                $"Сумма, руб.: {txtAmount.Text}\n" +
                $"Банк плательщика: {cmbPayerBank.SelectedItem}\n" +
                $"БИК: {txtBIC.Text}\n" +
                $"ИНН: {txtINN.Text}\n" +
                $"Тип плательщика: {selectedPersonType}\n" +
                $"Банк получателя: {cmbReceiverBank.SelectedItem}\n" +
                $"Счет получателя: {txtReceiverAccount.Text}";

            // Обновляем текст Label с результатами.
            lblResult.Text = result;
        }
    }
}
