﻿namespace Экзамен_аналог2
{
    partial class Form1
    {
        /// <summary>
        /// Обязательная переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Код, автоматически созданный конструктором форм Windows

        /// <summary>
        /// Требуемый метод для поддержки конструктора — не изменяйте 
        /// содержимое этого метода с помощью редактора кода.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.txtNumber = new System.Windows.Forms.TextBox();
            this.txtDate = new System.Windows.Forms.TextBox();
            this.txtPayer = new System.Windows.Forms.TextBox();
            this.txtAmount = new System.Windows.Forms.TextBox();
            this.txtBIC = new System.Windows.Forms.TextBox();
            this.txtINN = new System.Windows.Forms.TextBox();
            this.txtReceiverAccount = new System.Windows.Forms.TextBox();
            this.rbtnLegalPerson = new System.Windows.Forms.RadioButton();
            this.rbtnBusinessman = new System.Windows.Forms.RadioButton();
            this.cmbPayerBank = new System.Windows.Forms.ComboBox();
            this.cmbReceiverBank = new System.Windows.Forms.ComboBox();
            this.btnSend = new System.Windows.Forms.Button();
            this.btnCancel = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(12, 12);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(41, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Номер";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(12, 40);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(33, 13);
            this.label2.TabIndex = 1;
            this.label2.Text = "Дата";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(12, 67);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(71, 13);
            this.label3.TabIndex = 2;
            this.label3.Text = "Плательщик";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(12, 93);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(67, 13);
            this.label4.TabIndex = 3;
            this.label4.Text = "Сумма, руб.";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(13, 122);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(32, 13);
            this.label5.TabIndex = 4;
            this.label5.Text = "Банк";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(12, 149);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(73, 13);
            this.label6.TabIndex = 5;
            this.label6.Text = "БИК (9 цифр)";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(12, 175);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(96, 13);
            this.label7.TabIndex = 6;
            this.label7.Text = "ИНН (10-12 цифр)";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(12, 201);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(161, 13);
            this.label8.TabIndex = 7;
            this.label8.Text = "Юрлицо или предприниматель";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(12, 239);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(92, 13);
            this.label9.TabIndex = 8;
            this.label9.Text = "Банк получателя";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(12, 266);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(140, 13);
            this.label10.TabIndex = 9;
            this.label10.Text = "Счет получателя (20 цифр)";
            // 
            // txtNumber
            // 
            this.txtNumber.Enabled = false;
            this.txtNumber.Location = new System.Drawing.Point(193, 9);
            this.txtNumber.Name = "txtNumber";
            this.txtNumber.Size = new System.Drawing.Size(182, 20);
            this.txtNumber.TabIndex = 10;
            // 
            // txtDate
            // 
            this.txtDate.Enabled = false;
            this.txtDate.Location = new System.Drawing.Point(193, 37);
            this.txtDate.Name = "txtDate";
            this.txtDate.Size = new System.Drawing.Size(182, 20);
            this.txtDate.TabIndex = 11;
            // 
            // txtPayer
            // 
            this.txtPayer.Location = new System.Drawing.Point(193, 64);
            this.txtPayer.Name = "txtPayer";
            this.txtPayer.Size = new System.Drawing.Size(182, 20);
            this.txtPayer.TabIndex = 12;
            // 
            // txtAmount
            // 
            this.txtAmount.Location = new System.Drawing.Point(193, 90);
            this.txtAmount.Name = "txtAmount";
            this.txtAmount.Size = new System.Drawing.Size(182, 20);
            this.txtAmount.TabIndex = 13;
            // 
            // txtBIC
            // 
            this.txtBIC.Location = new System.Drawing.Point(193, 146);
            this.txtBIC.Name = "txtBIC";
            this.txtBIC.Size = new System.Drawing.Size(182, 20);
            this.txtBIC.TabIndex = 14;
            // 
            // txtINN
            // 
            this.txtINN.Location = new System.Drawing.Point(193, 172);
            this.txtINN.Name = "txtINN";
            this.txtINN.Size = new System.Drawing.Size(182, 20);
            this.txtINN.TabIndex = 15;
            // 
            // txtReceiverAccount
            // 
            this.txtReceiverAccount.Location = new System.Drawing.Point(193, 263);
            this.txtReceiverAccount.Name = "txtReceiverAccount";
            this.txtReceiverAccount.Size = new System.Drawing.Size(182, 20);
            this.txtReceiverAccount.TabIndex = 16;
            // 
            // rbtnLegalPerson
            // 
            this.rbtnLegalPerson.AutoSize = true;
            this.rbtnLegalPerson.Location = new System.Drawing.Point(193, 199);
            this.rbtnLegalPerson.Name = "rbtnLegalPerson";
            this.rbtnLegalPerson.Size = new System.Drawing.Size(64, 17);
            this.rbtnLegalPerson.TabIndex = 17;
            this.rbtnLegalPerson.TabStop = true;
            this.rbtnLegalPerson.Text = "Юрлицо";
            this.rbtnLegalPerson.UseVisualStyleBackColor = true;
            // 
            // rbtnBusinessman
            // 
            this.rbtnBusinessman.AutoSize = true;
            this.rbtnBusinessman.Location = new System.Drawing.Point(263, 199);
            this.rbtnBusinessman.Name = "rbtnBusinessman";
            this.rbtnBusinessman.Size = new System.Drawing.Size(118, 17);
            this.rbtnBusinessman.TabIndex = 18;
            this.rbtnBusinessman.TabStop = true;
            this.rbtnBusinessman.Text = "Предприниматель";
            this.rbtnBusinessman.UseVisualStyleBackColor = true;
            // 
            // cmbPayerBank
            // 
            this.cmbPayerBank.FormattingEnabled = true;
            this.cmbPayerBank.Location = new System.Drawing.Point(193, 119);
            this.cmbPayerBank.Name = "cmbPayerBank";
            this.cmbPayerBank.Size = new System.Drawing.Size(182, 21);
            this.cmbPayerBank.TabIndex = 19;
            // 
            // cmbReceiverBank
            // 
            this.cmbReceiverBank.FormattingEnabled = true;
            this.cmbReceiverBank.Location = new System.Drawing.Point(193, 236);
            this.cmbReceiverBank.Name = "cmbReceiverBank";
            this.cmbReceiverBank.Size = new System.Drawing.Size(182, 21);
            this.cmbReceiverBank.TabIndex = 20;
            // 
            // btnSend
            // 
            this.btnSend.Location = new System.Drawing.Point(235, 299);
            this.btnSend.Name = "btnSend";
            this.btnSend.Size = new System.Drawing.Size(75, 23);
            this.btnSend.TabIndex = 21;
            this.btnSend.Text = "Отправить";
            this.btnSend.UseVisualStyleBackColor = true;
            // 
            // btnCancel
            // 
            this.btnCancel.Location = new System.Drawing.Point(77, 299);
            this.btnCancel.Name = "btnCancel";
            this.btnCancel.Size = new System.Drawing.Size(75, 23);
            this.btnCancel.TabIndex = 22;
            this.btnCancel.Text = "Отменить";
            this.btnCancel.UseVisualStyleBackColor = true;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(413, 555);
            this.Controls.Add(this.btnCancel);
            this.Controls.Add(this.btnSend);
            this.Controls.Add(this.cmbReceiverBank);
            this.Controls.Add(this.cmbPayerBank);
            this.Controls.Add(this.rbtnBusinessman);
            this.Controls.Add(this.rbtnLegalPerson);
            this.Controls.Add(this.txtReceiverAccount);
            this.Controls.Add(this.txtINN);
            this.Controls.Add(this.txtBIC);
            this.Controls.Add(this.txtAmount);
            this.Controls.Add(this.txtPayer);
            this.Controls.Add(this.txtDate);
            this.Controls.Add(this.txtNumber);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "Form1";
            this.Text = "Финансовое поручение";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.TextBox txtNumber;
        private System.Windows.Forms.TextBox txtDate;
        private System.Windows.Forms.TextBox txtPayer;
        private System.Windows.Forms.TextBox txtAmount;
        private System.Windows.Forms.TextBox txtBIC;
        private System.Windows.Forms.TextBox txtINN;
        private System.Windows.Forms.TextBox txtReceiverAccount;
        private System.Windows.Forms.RadioButton rbtnLegalPerson;
        private System.Windows.Forms.RadioButton rbtnBusinessman;
        private System.Windows.Forms.ComboBox cmbPayerBank;
        private System.Windows.Forms.ComboBox cmbReceiverBank;
        private System.Windows.Forms.Button btnSend;
        private System.Windows.Forms.Button btnCancel;
    }
}

