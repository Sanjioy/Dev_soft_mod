﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Пр13_2_Стынгач
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            this.DoubleClick += new EventHandler(Form1_DoubleClick);
        }

        private void Form1_DoubleClick(object sender, EventArgs e)
        {
            // Создаем новый ColorDialog.
            ColorDialog colorDialog = new ColorDialog();

            // Открываем диалог выбора цвета.
            if (colorDialog.ShowDialog() == DialogResult.OK)
            {
                // Устанавливаем цвет формы в выбранный цвет.
                this.BackColor = colorDialog.Color;
            }
        }

        private void btnLoadImage_Click(object sender, EventArgs e)
        {
            OpenFileDialog openFileDialog = new OpenFileDialog();
            // Фильтр для файлов изображений.
            openFileDialog.Filter = "Image Files|*.jpg;*.jpeg;*.png;*.gif;*.bmp"; 

            if (openFileDialog.ShowDialog() == DialogResult.OK)
            {
                try
                {
                    // Загрузка изображения в PictureBox
                    pictureBox1.Image = Image.FromFile(openFileDialog.FileName);
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Не удалось загрузить изображение: " + ex.Message);
                }
            }
        }

        private void btnForm2_Click(object sender, EventArgs e)
        {
            Form2 newForm = new Form2();
            newForm.Show();
        }
    }
}
