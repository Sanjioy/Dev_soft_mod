﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml.Linq;

namespace Пр13_2_Стынгач
{
    public partial class Form2 : Form
    {
        // Имя файла для сохранения данных.
        private const string fileName = "sam3.txt"; 
        public Form2()
        {
            InitializeComponent();
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            string name = txtName.Text.Trim();
            string city = txtCity.Text.Trim();

            if (!string.IsNullOrEmpty(name) && !string.IsNullOrEmpty(city))
            {
                try
                {
                    using (StreamWriter writer = new StreamWriter(fileName, true))
                    {
                        writer.WriteLine($"Имя: {name}, Город: {city}");
                        MessageBox.Show("Данные успешно сохранены в файле.");
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Ошибка при сохранении данных: " + ex.Message);
                }
            }
            else
            {
                MessageBox.Show("Пожалуйста, введите имя и город.");
            }
        }

        private void btnLoad_Click(object sender, EventArgs e)
        {
            try
            {
                if (File.Exists(fileName))
                {
                    string[] lines = File.ReadAllLines(fileName);
                    string allData = string.Join("\n", lines);
                    MessageBox.Show(allData, "Содержимое файла sam3.txt");
                }
                else
                {
                    MessageBox.Show("Файл с данными не найден.");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ошибка при чтении данных из файла: " + ex.Message);
            }
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            // Очистить поле ввода имени при нажатии Отмена.
            txtName.Text = ""; 
            txtCity.Text = "";
        }

        private void btnForm3_Click(object sender, EventArgs e)
        {
            Form3 newForm = new Form3();
            newForm.Show();
        }
    }
}
