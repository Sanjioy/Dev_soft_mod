﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Пр13_2_Стынгач
{
    public partial class Form3 : Form
    {
        private const string fileName = "reg.txt";
        public Form3()
        {
            InitializeComponent();

            cmbSubjects.Items.Add("Физика");
            cmbSubjects.Items.Add("Математика");
            cmbSubjects.Items.Add("Информатика");
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            string name = txtName.Text.Trim();
            string selectedClass = GetSelectedClass();
            string selectedSubject = cmbSubjects.SelectedItem?.ToString();

            if (!string.IsNullOrEmpty(name) && !string.IsNullOrEmpty(selectedClass) && !string.IsNullOrEmpty(selectedSubject))
            {
                try
                {
                    using (StreamWriter writer = new StreamWriter(fileName, true))
                    {
                        writer.WriteLine($"Имя: {name}, Класс: {selectedClass}, Предмет: {selectedSubject}");
                        MessageBox.Show("Данные успешно сохранены в файле.");
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Ошибка при сохранении данных: " + ex.Message);
                }
            }
            else
            {
                MessageBox.Show("Пожалуйста, введите имя, выберите класс и предмет.");
            }
        }

        private void btnLoad_Click(object sender, EventArgs e)
        {
            try
            {
                if (File.Exists(fileName))
                {
                    string[] lines = File.ReadAllLines(fileName);
                    string allData = string.Join("\n", lines);
                    MessageBox.Show(allData, "Содержимое файла reg.txt");
                }
                else
                {
                    MessageBox.Show("Файл с данными не найден.");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ошибка при чтении данных из файла: " + ex.Message);
            }
        }

        private string GetSelectedClass()
        {
            if (radioBtnClass9.Checked)
            {
                return "9";
            }
            else if (radioBtnClass10.Checked)
            {
                return "10";
            }
            else if (radioBtnClass11.Checked)
            {
                return "11";
            }
            else
            {
                return "";
            }
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            // Очистить поля ввода имени при нажатии Отмена.
            txtName.Text = "";
            cmbSubjects.SelectedIndex = -1;
            radioBtnClass9.Checked = false;
            radioBtnClass10.Checked = false;
            radioBtnClass11.Checked = false;
        }
    }
}
