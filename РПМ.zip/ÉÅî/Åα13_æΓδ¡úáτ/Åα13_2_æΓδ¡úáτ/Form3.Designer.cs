﻿namespace Пр13_2_Стынгач
{
    partial class Form3
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnLoad = new System.Windows.Forms.Button();
            this.btnCancel = new System.Windows.Forms.Button();
            this.btnSave = new System.Windows.Forms.Button();
            this.txtName = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.radioBtnClass9 = new System.Windows.Forms.RadioButton();
            this.radioBtnClass10 = new System.Windows.Forms.RadioButton();
            this.radioBtnClass11 = new System.Windows.Forms.RadioButton();
            this.cmbSubjects = new System.Windows.Forms.ComboBox();
            this.openFileDialog1 = new System.Windows.Forms.OpenFileDialog();
            this.SuspendLayout();
            // 
            // btnLoad
            // 
            this.btnLoad.Location = new System.Drawing.Point(194, 103);
            this.btnLoad.Name = "btnLoad";
            this.btnLoad.Size = new System.Drawing.Size(75, 23);
            this.btnLoad.TabIndex = 14;
            this.btnLoad.Text = "Прочитать";
            this.btnLoad.UseVisualStyleBackColor = true;
            this.btnLoad.Click += new System.EventHandler(this.btnLoad_Click);
            // 
            // btnCancel
            // 
            this.btnCancel.Location = new System.Drawing.Point(103, 103);
            this.btnCancel.Name = "btnCancel";
            this.btnCancel.Size = new System.Drawing.Size(75, 23);
            this.btnCancel.TabIndex = 13;
            this.btnCancel.Text = "Отмена";
            this.btnCancel.UseVisualStyleBackColor = true;
            this.btnCancel.Click += new System.EventHandler(this.btnCancel_Click);
            // 
            // btnSave
            // 
            this.btnSave.Location = new System.Drawing.Point(14, 103);
            this.btnSave.Name = "btnSave";
            this.btnSave.Size = new System.Drawing.Size(75, 23);
            this.btnSave.TabIndex = 12;
            this.btnSave.Text = "Записать";
            this.btnSave.UseVisualStyleBackColor = true;
            this.btnSave.Click += new System.EventHandler(this.btnSave_Click);
            // 
            // txtName
            // 
            this.txtName.Location = new System.Drawing.Point(103, 15);
            this.txtName.Name = "txtName";
            this.txtName.Size = new System.Drawing.Size(100, 20);
            this.txtName.TabIndex = 10;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(11, 73);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(81, 13);
            this.label3.TabIndex = 9;
            this.label3.Text = "Введите город";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(11, 18);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(72, 13);
            this.label2.TabIndex = 8;
            this.label2.Text = "Введите имя";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(11, 46);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(90, 13);
            this.label1.TabIndex = 15;
            this.label1.Text = "Выберите класс";
            // 
            // radioBtnClass9
            // 
            this.radioBtnClass9.AutoSize = true;
            this.radioBtnClass9.Location = new System.Drawing.Point(103, 46);
            this.radioBtnClass9.Name = "radioBtnClass9";
            this.radioBtnClass9.Size = new System.Drawing.Size(31, 17);
            this.radioBtnClass9.TabIndex = 16;
            this.radioBtnClass9.TabStop = true;
            this.radioBtnClass9.Text = "9";
            this.radioBtnClass9.UseVisualStyleBackColor = true;
            // 
            // radioBtnClass10
            // 
            this.radioBtnClass10.AutoSize = true;
            this.radioBtnClass10.Location = new System.Drawing.Point(141, 46);
            this.radioBtnClass10.Name = "radioBtnClass10";
            this.radioBtnClass10.Size = new System.Drawing.Size(37, 17);
            this.radioBtnClass10.TabIndex = 17;
            this.radioBtnClass10.TabStop = true;
            this.radioBtnClass10.Text = "10";
            this.radioBtnClass10.UseVisualStyleBackColor = true;
            // 
            // radioBtnClass11
            // 
            this.radioBtnClass11.AutoSize = true;
            this.radioBtnClass11.Location = new System.Drawing.Point(185, 46);
            this.radioBtnClass11.Name = "radioBtnClass11";
            this.radioBtnClass11.Size = new System.Drawing.Size(37, 17);
            this.radioBtnClass11.TabIndex = 18;
            this.radioBtnClass11.TabStop = true;
            this.radioBtnClass11.Text = "11";
            this.radioBtnClass11.UseVisualStyleBackColor = true;
            // 
            // cmbSubjects
            // 
            this.cmbSubjects.FormattingEnabled = true;
            this.cmbSubjects.Location = new System.Drawing.Point(103, 73);
            this.cmbSubjects.Name = "cmbSubjects";
            this.cmbSubjects.Size = new System.Drawing.Size(100, 21);
            this.cmbSubjects.TabIndex = 19;
            // 
            // openFileDialog1
            // 
            this.openFileDialog1.FileName = "openFileDialog1";
            // 
            // Form3
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(298, 149);
            this.Controls.Add(this.cmbSubjects);
            this.Controls.Add(this.radioBtnClass11);
            this.Controls.Add(this.radioBtnClass10);
            this.Controls.Add(this.radioBtnClass9);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.btnLoad);
            this.Controls.Add(this.btnCancel);
            this.Controls.Add(this.btnSave);
            this.Controls.Add(this.txtName);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Name = "Form3";
            this.Text = "Form3";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnLoad;
        private System.Windows.Forms.Button btnCancel;
        private System.Windows.Forms.Button btnSave;
        private System.Windows.Forms.TextBox txtName;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.RadioButton radioBtnClass9;
        private System.Windows.Forms.RadioButton radioBtnClass10;
        private System.Windows.Forms.RadioButton radioBtnClass11;
        private System.Windows.Forms.ComboBox cmbSubjects;
        private System.Windows.Forms.OpenFileDialog openFileDialog1;
    }
}