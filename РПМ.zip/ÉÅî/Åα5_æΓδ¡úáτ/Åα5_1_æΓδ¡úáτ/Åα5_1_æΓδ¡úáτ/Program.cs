﻿using System;

namespace Пр5_1_Стынгач
{
    
    class Build
    {
        public string name;
        public int floor;
        public double area;
        public int kvo;
        public void ShowInfo()
        {
            Console.WriteLine("В доме {0} c {1} этажами площадью {2} живет {3} чел, на человека {4:f3}",
                name, floor, area, kvo, area / kvo);
        }
        public Build() { }
        public Build(string nm, int fl, double ar, int k)
        { this.name = nm; this.floor = fl;  this.area = ar; this.kvo = k; }
    }
    class Program
    {
        static void Main(string[] args)
        {
            Build dom1 = new Build();
            dom1.name = "Дача";
            dom1.floor = 2;
            dom1.area = 30;
            dom1.kvo = 4;
            dom1.ShowInfo();

            Build dom2 = new Build("Коттедж", 3, 80, 6);
            dom2.ShowInfo();

            Build dom3 = new Build();
            dom3.name = "Хата";
            dom3.floor = 5;
            dom3.area = 100;
            dom3.kvo = 2;
            dom3.ShowInfo();

            Build dom4 = new Build("Дворец", 6, 500, 12);
            dom4.ShowInfo();
        }
    }
}
