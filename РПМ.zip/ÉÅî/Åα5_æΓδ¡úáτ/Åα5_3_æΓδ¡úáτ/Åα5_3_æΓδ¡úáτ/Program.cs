﻿using System;

namespace Пр5_3_Стынгач
{
    /*Класс Student. Метод ShowInfo выводит фамилию, имя, курс, возраст.*/
    class Student
    {
        public string surname;
        public string name;
        public int cource;
        public int age;

        public void ShowInfo()
        {
            Console.WriteLine("Студент {0} {1} проходит {2} курс колледжа, ему {3} лет/год(-a).",
                surname, name, cource, age);
        }
    }

    /*Класс Computer. Метод Info выводит модель (IBM, Asus, Sony) 
    и параметры компьютера (объем ОЗУ и жесткого диска).*/
    class Computer
    {
        public string model;
        public int ram;
        public int disk;

        public void Info()
        {
            Console.WriteLine("Компьютер {0} имеет {1} GB оперативной памяти и {2} GB объем жесткого диска.",
                model, ram, disk);
        }
        public Computer() { }
        public Computer(string model, int ram, int disk)
        { this.model = model; this.ram = ram; this.disk = disk; }
    }

    /*Класс Tovar. Метод Kupi выводит название (тетрадь, книга, ручка), 
    цену, наличие на складе (есть, нет), количество.*/
    class Tovar
    {
        public string name;
        public double price;
        public string have;
        public int count;

        public void Kupi()
        {
            Console.WriteLine("{0} стоит {1} рублей, {2} на складе в кличестве {3} штук.",
                name, price, have, count);
        }
        public Tovar() { }
        public Tovar(string name, double price, string have, int count)
        { this.name = name; this.price = price; this.have = have; this.count = count; }


    }

    /*Класс Pogoda. Метод Show выводит город (Минск, Брест, Гомель), 
    температуру, осадки (ясно, пасмурно, гроза), направление и скорость ветра.*/
    class Pogoda
    {
        public string city;
        public double temp;
        public string osadki;
        public string orientation;
        public double speed;

        public void Show()
        {
            Console.WriteLine("В городе {0} {1} градусов, {2}, направление ветра: {3}, скорость: {4} м/с.",
                city, temp, osadki, orientation, speed);
        }
        public Pogoda() { }
        public Pogoda(string city, double temp, string osadki, string orientation, double speed)
        { this.city = city; this.temp = temp; this.osadki = osadki; this.orientation = orientation; this.speed = speed; }


    }

    /*Kласс Transport. Метод ShowInfo выводит параметры 
    транспортного средства: тип (автомобиль, мотоцикл, велосипед), цвет, скорость, масса.*/
    class Transport
    {
        public string type;
        public string color;
        public double speed;
        public int mass;


        public void ShowInfo()
        {
            Console.WriteLine("{0} {1} цвета, разгоняется до {2} км/ч, имеет массу {3} кг.",
                type, color, speed, mass);
        }
        public Transport() { }
        public Transport(string type, string color, double speed, int mass)
        { this.type = type; this.color = color; this.speed = speed; this.mass = mass; }


    }

    /*Класс Animal. Метод Golos выводит вид (кошка, собака, попугай), имя
    (Мурка, Шарик, Кеша), голос (мяу, гав, ррр).*/
    class Animal
    {
        public string type;
        public string name;
        public string golos;


        public void Golos()
        {
            Console.WriteLine("{0} {1} говорит {2}.",
                type, name, golos);
        }
        public Animal() { }
        public Animal(string type, string color, string golos)
        { this.type = type; this.name = color; this.golos = golos; }


    }

    /*Класс Figura. Метод ShowArea выводит название (квадрат, прямоугольник) и 
    параметры фигуры (основание, высоту), вычисляет и выводит площадь.*/
    class Figura
    {
        public string type;
        public double foot;
        public double height;



        public void ShowArea()
        {
            Console.WriteLine("{0} имеет основание = {1}, высота = {2}, S = {3}.",
                type, foot, height, foot * height);
        }
        public Figura() { }
        public Figura(string type, double foot, double height)
        { this.type = type; this.foot = foot; this.height = height; }


    }

    class Program
    {
        static void Main(string[] args)
        {
            Student first = new Student();
            first.surname = "Стынгач"; first.name = "Даниэль"; first.cource = 3; first.age = 18;
            first.ShowInfo();

            Computer second = new Computer("Asus", 16, 512);
            second.Info();

            Tovar third = new Tovar("Ручка", 20, "есть", 100);
            third.Kupi();

            Pogoda fourth = new Pogoda("Минск", 10, "ясно", "СЗ", 2);
            fourth.Show();

            Transport fifth = new Transport("Автомобиль", "красного", 252, 1900);
            fifth.ShowInfo();

            Animal sixth = new Animal("Кошка", "Мурка", "мяу");
            sixth.Golos();

            Figura seventh = new Figura("Квадрат", 4, 4);
            seventh.ShowArea();
        }
    }
}
