﻿using System;

namespace Пр5_2_Стынгач
{
    class Parallelepiped
    {
        // Поля данных представляют стороны параллелепипеда
        private double a, b, c;

        // Методы для установки и считывания значений полей
        public void Set_a(double pa) { a = pa; }
        public double Get_a() { return a; }

        public void Set_b(double pb) { b = pb; }
        public double Get_b() { return b; }

        public void Set_c(double pc) { c = pc; }
        public double Get_c() { return c; }

        // Метод для вычисления объема прямоугольного параллелепипеда
        public double GetV()
        {
            return a * b * c;
        }

        // Метод для вычисления площади поверхности прямоугольного параллелепипеда
        public double GetS()
        {
            return 2 * (a * b + b * c + a * c);
        }

        // Метод для вывода полной информации об объектах в консоль
        public void PrintFullInformation()
        {
            string str = "*****************************************************\n" +
                            "*                                                   *\n" +
                            "*         Объект прямоугольной параллелепипед       *\n" +
                            "*                                                   *\n" +
                            "*****************************************************";
            Console.WriteLine("Стороны прямоугольного параллелепипеда:\n" +
                "высота = {0}\n" +
                "длина = {1}\n" +
                "ширина = {2}", a, b, c);
            Console.WriteLine("Объем параллелепипеда равен {0}", GetV());
            Console.Write("Площадь поверхности равна {0}", GetS());
        }
    }

    class Program
    {
        static void Main(string[] args)
        {
            Console.Title = "Прямоугольный параллелепипед";
            Console.ForegroundColor = ConsoleColor.Yellow;
            Console.BackgroundColor = ConsoleColor.Red;
            Console.Clear();

            Parallelepiped p;

            p = new Parallelepiped();
            p.Set_a(10.5);
            p.Set_b(25.67);
            p.Set_c(40);

            p.PrintFullInformation();

            Console.ReadKey();
        }
    }
}
