﻿using System;

class Program
{
    static void Main()
    {
        int[] numbers = new int[4];
        int negativeCount = 0;

        Console.WriteLine("Введите четыре числа:");

        for (int i = 0; i < 4; i++)
        {
            Console.Write($"Число {i + 1}: ");
            if (!int.TryParse(Console.ReadLine(), out numbers[i]))
            {
                Console.WriteLine("Ошибка! Введите целое число.");
                i--; // Повторить попытку ввода для текущего числа
                continue;
            }

            switch (Math.Sign(numbers[i]))
            {
                case -1:
                    negativeCount++;
                    break;
                case 0:
                case 1:
                    // Если число не отрицательное, не делаем ничего
                    break;
            }
        }

        Console.WriteLine($"Среди введенных чисел {negativeCount} отрицательных.");
    }
}
