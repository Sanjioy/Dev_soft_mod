﻿using System;

namespace Пр1_1_2_Стынгач
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.Title = "Оператор IF";
            Console.BackgroundColor = ConsoleColor.White;
            Console.Clear();
            Console.ForegroundColor = ConsoleColor.Black;
            Console.WriteLine(DateTime.Now);
            Console.WriteLine("Стынгач Даниел Михайлович");
            Console.Write("Введите a: ");
            double a = Convert.ToDouble(Console.ReadLine());
            Console.Write("Введите b: ");
            double b = Convert.ToDouble(Console.ReadLine());
            double s;
            //Вычисление значения S
            if (a <= 3)
            {
                s = (Math.Pow(a * b * b, 1.0 / 3));
            }
            else
            {
                if (a <= 8)
                {
                    s = a - b;
                }
                else
                {
                    s = a + b;
                }
            }
            Console.WriteLine("s = {0}", s);
        }
    }
}
