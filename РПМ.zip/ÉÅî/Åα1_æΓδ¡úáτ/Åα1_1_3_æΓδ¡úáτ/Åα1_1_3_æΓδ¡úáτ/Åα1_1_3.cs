﻿using System;

namespace Пр1_1_3_Стынгач
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.Title = "Задание №2";
            Console.BackgroundColor = ConsoleColor.White;
            Console.Clear();
            Console.ForegroundColor = ConsoleColor.Black;
            Console.WriteLine(System.DateTime.Now);
            Console.WriteLine("Стынгач Даниел Михайлович");

            int x, y, R;

            // Функция для проверки на целое число
            int GetIntegerFromConsole(string message)
            {
                int value;
                Console.Write(message);
                while (!int.TryParse(Console.ReadLine(), out value))
                {
                    Console.WriteLine("Введите целое число!");
                    Console.Write(message);
                }
                return value;
            }

            x = GetIntegerFromConsole("Введите x: ");
            y = GetIntegerFromConsole("Введите y: ");
            R = GetIntegerFromConsole("Введите R: ");

            if (R * R > x * x + y * y)
            {
                Console.WriteLine("Точка не попала");
            }
            else if (R * R == x * x + y * y)
            {
                Console.WriteLine("Граница");
            }
            else
            {
                Console.WriteLine("Точка попала");
            }
        }
    }
}
