﻿using System;

namespace pr1_1_1_Стынгач
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.Title = "Оператор switch";
            Console.BackgroundColor = ConsoleColor.White;
            Console.Clear();
            Console.ForegroundColor = ConsoleColor.Black;
            Console.WriteLine(System.DateTime.Now);
            Console.WriteLine("Стынгач Даниел Михайлович");
            string Math = "1 - Синус \n" +
                "2 - Косинус \n" +
                "3 - Возведение в степень \n" +
                "4 - Квадратный корень \n" +
                "5 - Модуль числа \n" +
                "6 - Логарифм \n";

            Console.Write(Math + "Введите номер, из представленных выше >> ");
            int result = Convert.ToInt32(Console.ReadLine());

            switch (result)
            {
                case 1:
                    {
                        Console.WriteLine("Синус - отношение противолежащего катета к гипотенузе: " +
                "Это отношение не зависит от выбора треугольника, содержащего угол так как " +
                "все такие треугольники подобны.");
                        break;
                    }
                case 2:
                    {
                        Console.WriteLine("Косинус - отношение прилежащего катета к гипотенузе: " +
                "Так как синус одного острого угла в треугольнике равна " +
                "косинусу второго, и наоборот.");
                        break;
                    }
                case 3:
                    {
                        Console.WriteLine("Возведение в степень - арифметическая операция, " +
                "первоначально определяемая как результат многократного умножения числа на себя.");
                        break;
                    }
                case 4:
                    {
                        Console.WriteLine("Квадратный корень - это значение, " +
                "которое дает исходное число, которое умножается само на себя.");
                        break;
                    }
                case 5:
                    {
                        Console.WriteLine("Модуль числа - это число, равное ему самому, " +
                "если число положительное, противоположному числу, " +
                "если оно отрицательное, и все равно какому, если число равно нулю.");
                        break;
                    }
                case 6:
                    {
                        Console.WriteLine("Логарифм - это функция, обратная возведению в степень.");
                        break;
                    }
                default:
                    Console.WriteLine("Это не СЧАСТЬЕ!!!");
                    break;
            }

        }
    }
}
