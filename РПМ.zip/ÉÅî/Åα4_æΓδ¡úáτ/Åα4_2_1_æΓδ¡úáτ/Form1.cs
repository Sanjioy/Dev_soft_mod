namespace Пр4_2_1_Стынгач
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        int[] Mas = new int[15];

        private void btnFillArray_Click(object sender, EventArgs e)
        {
            // Очищает элемент управления
            listBoxSourceArray.Items.Clear();
            // Инициализируем класс случайных чисел
            Random rnd = new Random();
            // Генерируем и выводим 15 элементов из диапазона от -50 до 50
            for (int i = 0; i < 15; i++)
            {
                Mas[i] = rnd.Next(-50, 50);
                listBoxSourceArray.Items.Add("Mas[" + i.ToString() + "] = " + Mas[i].ToString());
            }
        }

        private void btnConvertArray_Click(object sender, EventArgs e)
        {
            // Очищаем элемент управления.
            listBoxResultArray.Items.Clear();
            for (int i = 0; i < 15; i++)
            {
                if (Mas[i] < 0)
                    Mas[i] = 0;
                listBoxResultArray.Items.Add("Mas[" + i.ToString() + "] = " + Mas[i].ToString());
            }
        }
    }
}