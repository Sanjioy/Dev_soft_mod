﻿namespace Пр4_2_1_Стынгач
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label1 = new Label();
            label2 = new Label();
            label3 = new Label();
            listBoxSourceArray = new ListBox();
            listBoxResultArray = new ListBox();
            btnFillArray = new Button();
            btnConvertArray = new Button();
            SuspendLayout();
            // 
            // label1
            // 
            label1.BackColor = SystemColors.Info;
            label1.Font = new Font("Segoe UI", 14F, FontStyle.Regular, GraphicsUnit.Point);
            label1.Location = new Point(27, 19);
            label1.Name = "label1";
            label1.Size = new Size(465, 80);
            label1.TabIndex = 0;
            label1.Text = "Программа создает одномерный массив, заполняет его случайными числами и заменяет в этом массиве все отрицательные числа нулями.";
            label1.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(61, 129);
            label2.Name = "label2";
            label2.Size = new Size(107, 15);
            label2.TabIndex = 1;
            label2.Text = "Исходный массив";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(319, 129);
            label3.Name = "label3";
            label3.Size = new Size(147, 15);
            label3.TabIndex = 2;
            label3.Text = "Результирующий массив";
            // 
            // listBoxSourceArray
            // 
            listBoxSourceArray.FormattingEnabled = true;
            listBoxSourceArray.ItemHeight = 15;
            listBoxSourceArray.Location = new Point(27, 155);
            listBoxSourceArray.Name = "listBoxSourceArray";
            listBoxSourceArray.Size = new Size(190, 379);
            listBoxSourceArray.TabIndex = 3;
            // 
            // listBoxResultArray
            // 
            listBoxResultArray.FormattingEnabled = true;
            listBoxResultArray.ItemHeight = 15;
            listBoxResultArray.Location = new Point(296, 157);
            listBoxResultArray.Name = "listBoxResultArray";
            listBoxResultArray.Size = new Size(196, 379);
            listBoxResultArray.TabIndex = 4;
            // 
            // btnFillArray
            // 
            btnFillArray.BackColor = SystemColors.ActiveCaption;
            btnFillArray.Location = new Point(61, 558);
            btnFillArray.Name = "btnFillArray";
            btnFillArray.Size = new Size(119, 23);
            btnFillArray.TabIndex = 5;
            btnFillArray.Text = "Заполнить массив";
            btnFillArray.UseVisualStyleBackColor = false;
            btnFillArray.Click += btnFillArray_Click;
            // 
            // btnConvertArray
            // 
            btnConvertArray.BackColor = SystemColors.ActiveCaption;
            btnConvertArray.Location = new Point(319, 558);
            btnConvertArray.Name = "btnConvertArray";
            btnConvertArray.Size = new Size(147, 23);
            btnConvertArray.TabIndex = 6;
            btnConvertArray.Text = "Преобразовать массив";
            btnConvertArray.UseVisualStyleBackColor = false;
            btnConvertArray.Click += btnConvertArray_Click;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(521, 618);
            Controls.Add(btnConvertArray);
            Controls.Add(btnFillArray);
            Controls.Add(listBoxResultArray);
            Controls.Add(listBoxSourceArray);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(label1);
            Name = "Form1";
            Text = "Form1";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private Label label2;
        private Label label3;
        private ListBox listBoxSourceArray;
        private ListBox listBoxResultArray;
        private Button btnFillArray;
        private Button btnConvertArray;
    }
}