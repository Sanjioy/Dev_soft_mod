﻿namespace Пр4_2_2_Стынгач
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            minPositiveLabel = new Label();
            productOfOddLabel = new Label();
            inputTextBox = new TextBox();
            negativeElementsTextBox = new TextBox();
            calculateButton = new Button();
            label1 = new Label();
            label2 = new Label();
            label3 = new Label();
            label4 = new Label();
            SuspendLayout();
            // 
            // minPositiveLabel
            // 
            minPositiveLabel.AutoSize = true;
            minPositiveLabel.Location = new Point(208, 28);
            minPositiveLabel.Name = "minPositiveLabel";
            minPositiveLabel.Size = new Size(0, 15);
            minPositiveLabel.TabIndex = 0;
            // 
            // productOfOddLabel
            // 
            productOfOddLabel.AutoSize = true;
            productOfOddLabel.Location = new Point(12, 84);
            productOfOddLabel.Name = "productOfOddLabel";
            productOfOddLabel.Size = new Size(0, 15);
            productOfOddLabel.TabIndex = 1;
            // 
            // inputTextBox
            // 
            inputTextBox.Location = new Point(12, 25);
            inputTextBox.Multiline = true;
            inputTextBox.Name = "inputTextBox";
            inputTextBox.ScrollBars = ScrollBars.Both;
            inputTextBox.Size = new Size(179, 26);
            inputTextBox.TabIndex = 2;
            // 
            // negativeElementsTextBox
            // 
            negativeElementsTextBox.Location = new Point(250, 81);
            negativeElementsTextBox.Multiline = true;
            negativeElementsTextBox.Name = "negativeElementsTextBox";
            negativeElementsTextBox.ScrollBars = ScrollBars.Both;
            negativeElementsTextBox.Size = new Size(179, 26);
            negativeElementsTextBox.TabIndex = 3;
            // 
            // calculateButton
            // 
            calculateButton.Location = new Point(350, 126);
            calculateButton.Name = "calculateButton";
            calculateButton.Size = new Size(79, 23);
            calculateButton.TabIndex = 4;
            calculateButton.Text = "Вычислить";
            calculateButton.UseVisualStyleBackColor = true;
            calculateButton.Click += calculateButton_Click;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(88, 7);
            label1.Name = "label1";
            label1.Size = new Size(28, 15);
            label1.TabIndex = 5;
            label1.Text = "19.1";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(331, 7);
            label2.Name = "label2";
            label2.Size = new Size(28, 15);
            label2.TabIndex = 6;
            label2.Text = "19.2";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(88, 63);
            label3.Name = "label3";
            label3.Size = new Size(28, 15);
            label3.TabIndex = 7;
            label3.Text = "19.3";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(331, 63);
            label4.Name = "label4";
            label4.Size = new Size(28, 15);
            label4.TabIndex = 8;
            label4.Text = "19.4";
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(485, 160);
            Controls.Add(label4);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(label1);
            Controls.Add(calculateButton);
            Controls.Add(negativeElementsTextBox);
            Controls.Add(inputTextBox);
            Controls.Add(productOfOddLabel);
            Controls.Add(minPositiveLabel);
            Name = "Form1";
            Text = "Form1";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label minPositiveLabel;
        private Label productOfOddLabel;
        private TextBox inputTextBox;
        private TextBox negativeElementsTextBox;
        private Button calculateButton;
        private Label label1;
        private Label label2;
        private Label label3;
        private Label label4;
    }
}