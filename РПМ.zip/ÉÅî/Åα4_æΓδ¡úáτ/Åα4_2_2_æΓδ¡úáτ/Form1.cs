namespace Пр4_2_2_Стынгач
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void calculateButton_Click(object sender, EventArgs e)
        {
            // Получение массива из текстового поля
            string input = inputTextBox.Text;
            string[] values = input.Split(new char[] { ' ' }, StringSplitOptions.RemoveEmptyEntries);

            // Парсинг строк в целые числа
            int[] array = Array.ConvertAll(values, int.Parse);

            int minPositive = FindMinPositive(array);
            int productOfOdd = CalculateProductOfOdd(array);

            // Отображение минимального положительного элемента
            minPositiveLabel.Text = $"Минимальный положительный элемент: {minPositive}";

            // Отображение произведения нечетных элементов
            productOfOddLabel.Text = $"Произведение нечетных элементов: {productOfOdd}";

            // Отображение отрицательных элементов
            negativeElementsTextBox.Text = GetNegativeElements(array);
        }

        // Функция для поиска минимального положительного элемента.
        private int FindMinPositive(int[] array)
        {
            int minPositive = int.MaxValue;

            foreach (int num in array)
            {
                if (num > 0 && num < minPositive)
                {
                    minPositive = num;
                }
            }

            return minPositive == int.MaxValue ? -1 : minPositive;
        }

        // Функция для вычисления произведения нечетных элементов.
        private int CalculateProductOfOdd(int[] array)
        {
            int product = 1;
            bool foundOdd = false;

            for (int i = 0; i < array.Length; i += 2)
            {
                product *= array[i];
                foundOdd = true;
            }
            // Возвращаем 0, если нет подходящих элементов.
            return foundOdd ? product : 0;
        }


        // Функция для получения отрицательных элементов в виде строки.
        private string GetNegativeElements(int[] array)
        {
            var negativeElements = array.Where(num => num < 0);
            return string.Join(" ", negativeElements);
        }
    }
}
