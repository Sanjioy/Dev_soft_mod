﻿namespace Пр4_2_3_Стынгач
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label1 = new Label();
            textBoxN = new TextBox();
            label2 = new Label();
            textBoxM = new TextBox();
            label3 = new Label();
            textBoxK = new TextBox();
            dGVSourceArray = new DataGridView();
            listBoxResultArray = new ListBox();
            btnSetArray = new Button();
            btnOutputArray = new Button();
            btnExit = new Button();
            ((System.ComponentModel.ISupportInitialize)dGVSourceArray).BeginInit();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(16, 16);
            label1.Name = "label1";
            label1.Size = new Size(127, 15);
            label1.TabIndex = 0;
            label1.Text = "Размерность массива";
            // 
            // textBoxN
            // 
            textBoxN.Location = new Point(175, 13);
            textBoxN.Name = "textBoxN";
            textBoxN.Size = new Size(47, 23);
            textBoxN.TabIndex = 1;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(228, 16);
            label2.Name = "label2";
            label2.Size = new Size(13, 15);
            label2.TabIndex = 2;
            label2.Text = "x";
            // 
            // textBoxM
            // 
            textBoxM.Location = new Point(247, 13);
            textBoxM.Name = "textBoxM";
            textBoxM.Size = new Size(46, 23);
            textBoxM.TabIndex = 2;
            // 
            // label3
            // 
            label3.Location = new Point(446, 13);
            label3.Name = "label3";
            label3.Size = new Size(131, 65);
            label3.TabIndex = 0;
            label3.Text = "Количество нечетных элементов на четных \r\n\r\nместах";
            // 
            // textBoxK
            // 
            textBoxK.Enabled = false;
            textBoxK.Location = new Point(510, 55);
            textBoxK.Name = "textBoxK";
            textBoxK.Size = new Size(67, 23);
            textBoxK.TabIndex = 0;
            // 
            // dGVSourceArray
            // 
            dGVSourceArray.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dGVSourceArray.Location = new Point(17, 55);
            dGVSourceArray.Name = "dGVSourceArray";
            dGVSourceArray.RowTemplate.Height = 25;
            dGVSourceArray.Size = new Size(407, 319);
            dGVSourceArray.TabIndex = 3;
            // 
            // listBoxResultArray
            // 
            listBoxResultArray.Enabled = false;
            listBoxResultArray.FormattingEnabled = true;
            listBoxResultArray.ItemHeight = 15;
            listBoxResultArray.Location = new Point(447, 98);
            listBoxResultArray.Name = "listBoxResultArray";
            listBoxResultArray.Size = new Size(130, 274);
            listBoxResultArray.TabIndex = 0;
            // 
            // btnSetArray
            // 
            btnSetArray.Location = new Point(42, 395);
            btnSetArray.Name = "btnSetArray";
            btnSetArray.Size = new Size(180, 23);
            btnSetArray.TabIndex = 4;
            btnSetArray.Text = "Задать массив";
            btnSetArray.UseVisualStyleBackColor = true;
            btnSetArray.Click += btnSetArray_Click;
            // 
            // btnOutputArray
            // 
            btnOutputArray.Location = new Point(247, 395);
            btnOutputArray.Name = "btnOutputArray";
            btnOutputArray.Size = new Size(154, 23);
            btnOutputArray.TabIndex = 5;
            btnOutputArray.Text = "Вывод массива";
            btnOutputArray.UseVisualStyleBackColor = true;
            btnOutputArray.Click += btnOutputArray_Click;
            // 
            // btnExit
            // 
            btnExit.Location = new Point(447, 395);
            btnExit.Name = "btnExit";
            btnExit.Size = new Size(130, 23);
            btnExit.TabIndex = 6;
            btnExit.Text = "Выход";
            btnExit.UseVisualStyleBackColor = true;
            btnExit.Click += btnExit_Click;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(604, 450);
            Controls.Add(btnExit);
            Controls.Add(btnOutputArray);
            Controls.Add(btnSetArray);
            Controls.Add(listBoxResultArray);
            Controls.Add(dGVSourceArray);
            Controls.Add(textBoxK);
            Controls.Add(label3);
            Controls.Add(textBoxM);
            Controls.Add(label2);
            Controls.Add(textBoxN);
            Controls.Add(label1);
            Name = "Form1";
            Text = "Form1";
            ((System.ComponentModel.ISupportInitialize)dGVSourceArray).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private TextBox textBoxN;
        private Label label2;
        private TextBox textBoxM;
        private Label label3;
        private TextBox textBoxK;
        private DataGridView dGVSourceArray;
        private ListBox listBoxResultArray;
        private Button btnSetArray;
        private Button btnOutputArray;
        private Button btnExit;
    }
}