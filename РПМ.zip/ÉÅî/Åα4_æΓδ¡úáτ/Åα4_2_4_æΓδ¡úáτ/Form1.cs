namespace Пр4_2_4_Стынгач
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnSetArray_Click(object sender, EventArgs e)
        {
            int k = Convert.ToInt32(textBoxK.Text);
            int m = Convert.ToInt32(textBoxM.Text);

            // Добавление столбцов в dataGridView dGVSourceArray.
            for (int i = 0; i <= m; i++)
            {
                dGVSourceArray.Columns.Add("", "");
                // Установка заголовков столбцов, кроме первого.
                if (i > 0)
                    dGVSourceArray.Columns[i].HeaderText = Convert.ToString(i - 1);
                // Установка ширины столбцов.
                dGVSourceArray.Columns[i].Width = 40;
            }

            // Добавление строк в dataGridView dGVSourceArray.
            for (int i = 0; i < k; i++)
            {
                dGVSourceArray.Rows.Add(Convert.ToString(i), "");
            }

            // Скрыть кнопку "Задать массив" после ее срабатывания
            btnSetArray.Visible = false;
        }

        private void btnOutputArray_Click(object sender, EventArgs e)
        {
            int k = Convert.ToInt32(textBoxK.Text);
            int m = Convert.ToInt32(textBoxM.Text);
            int a = Convert.ToInt32(textBoxA.Text);

            // Создаем список для хранения чисел больше A.
            List<int> numbersList = new List<int>();

            // Заполнение списка numbersList данными из dataGridView dGVSourceArray.
            for (int i = 0; i < k; i++)
            {
                for (int j = 0; j < m; j++)
                {
                    // Проверяем, не является ли значение ячейки пустым или null.
                    if (dGVSourceArray.Rows[i].Cells[j + 1].Value != null);
                    {
                        // Преобразуем значение ячейки в строку для последующей проверки на число.
                        string cellValue = dGVSourceArray.Rows[i].Cells[j + 1].Value.ToString();
                        int value;
                        // Пытаемся преобразовать строку в число.
                        if (int.TryParse(cellValue, out value))
                        {
                            if (value > a)
                            {
                                numbersList.Add(value);
                            }
                        }
                    }                   
                }
            }

            // Создание строки из списка чисел больше A через запятую
            string resultString = string.Join(", ", numbersList);

            // Добавление строки в listBoxResultArray
            listBoxResultArray.Items.Add(resultString);

            // Скрыть кнопку "Вывод массива" после ее срабатывания
            btnOutputArray.Visible = false;
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}