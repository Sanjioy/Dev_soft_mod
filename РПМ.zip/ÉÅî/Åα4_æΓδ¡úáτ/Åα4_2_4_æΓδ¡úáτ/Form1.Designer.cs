﻿namespace Пр4_2_4_Стынгач
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            btnOutputArray = new Button();
            btnSetArray = new Button();
            dGVSourceArray = new DataGridView();
            textBoxM = new TextBox();
            label2 = new Label();
            textBoxK = new TextBox();
            label1 = new Label();
            listBoxResultArray = new ListBox();
            textBoxA = new TextBox();
            label3 = new Label();
            btnExit = new Button();
            ((System.ComponentModel.ISupportInitialize)dGVSourceArray).BeginInit();
            SuspendLayout();
            // 
            // btnOutputArray
            // 
            btnOutputArray.Location = new Point(242, 394);
            btnOutputArray.Name = "btnOutputArray";
            btnOutputArray.Size = new Size(154, 23);
            btnOutputArray.TabIndex = 6;
            btnOutputArray.Text = "Вывод массива";
            btnOutputArray.UseVisualStyleBackColor = true;
            btnOutputArray.Click += btnOutputArray_Click;
            // 
            // btnSetArray
            // 
            btnSetArray.Location = new Point(37, 394);
            btnSetArray.Name = "btnSetArray";
            btnSetArray.Size = new Size(180, 23);
            btnSetArray.TabIndex = 3;
            btnSetArray.Text = "Задать массив";
            btnSetArray.UseVisualStyleBackColor = true;
            btnSetArray.Click += btnSetArray_Click;
            // 
            // dGVSourceArray
            // 
            dGVSourceArray.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dGVSourceArray.Location = new Point(12, 54);
            dGVSourceArray.Name = "dGVSourceArray";
            dGVSourceArray.RowTemplate.Height = 25;
            dGVSourceArray.Size = new Size(407, 319);
            dGVSourceArray.TabIndex = 4;
            // 
            // textBoxM
            // 
            textBoxM.Location = new Point(242, 12);
            textBoxM.Name = "textBoxM";
            textBoxM.Size = new Size(46, 23);
            textBoxM.TabIndex = 2;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(223, 15);
            label2.Name = "label2";
            label2.Size = new Size(13, 15);
            label2.TabIndex = 9;
            label2.Text = "x";
            // 
            // textBoxK
            // 
            textBoxK.Location = new Point(170, 12);
            textBoxK.Name = "textBoxK";
            textBoxK.Size = new Size(47, 23);
            textBoxK.TabIndex = 1;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(11, 15);
            label1.Name = "label1";
            label1.Size = new Size(127, 15);
            label1.TabIndex = 6;
            label1.Text = "Размерность массива";
            // 
            // listBoxResultArray
            // 
            listBoxResultArray.Enabled = false;
            listBoxResultArray.FormattingEnabled = true;
            listBoxResultArray.ItemHeight = 15;
            listBoxResultArray.Location = new Point(445, 54);
            listBoxResultArray.Name = "listBoxResultArray";
            listBoxResultArray.Size = new Size(192, 319);
            listBoxResultArray.TabIndex = 13;
            // 
            // textBoxA
            // 
            textBoxA.Location = new Point(570, 12);
            textBoxA.Name = "textBoxA";
            textBoxA.Size = new Size(67, 23);
            textBoxA.TabIndex = 5;
            // 
            // label3
            // 
            label3.Location = new Point(445, 15);
            label3.Name = "label3";
            label3.Size = new Size(105, 21);
            label3.TabIndex = 15;
            label3.Text = "Введите число A";
            // 
            // btnExit
            // 
            btnExit.Location = new Point(476, 394);
            btnExit.Name = "btnExit";
            btnExit.Size = new Size(130, 23);
            btnExit.TabIndex = 16;
            btnExit.Text = "Выход";
            btnExit.UseVisualStyleBackColor = true;
            btnExit.Click += btnExit_Click;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(664, 450);
            Controls.Add(btnExit);
            Controls.Add(listBoxResultArray);
            Controls.Add(textBoxA);
            Controls.Add(label3);
            Controls.Add(btnOutputArray);
            Controls.Add(btnSetArray);
            Controls.Add(dGVSourceArray);
            Controls.Add(textBoxM);
            Controls.Add(label2);
            Controls.Add(textBoxK);
            Controls.Add(label1);
            Name = "Form1";
            Text = "Form1";
            ((System.ComponentModel.ISupportInitialize)dGVSourceArray).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button btnOutputArray;
        private Button btnSetArray;
        private DataGridView dGVSourceArray;
        private TextBox textBoxM;
        private Label label2;
        private TextBox textBoxK;
        private Label label1;
        private ListBox listBoxResultArray;
        private TextBox textBoxA;
        private Label label3;
        private Button btnExit;
    }
}