﻿namespace Пр4_2_5_Стынгач
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            textBoxM = new TextBox();
            label2 = new Label();
            textBoxN = new TextBox();
            label1 = new Label();
            textBoxK = new TextBox();
            label3 = new Label();
            btnExit = new Button();
            btnOutputMatrix = new Button();
            btnCreateMatrix = new Button();
            btnClear = new Button();
            SuspendLayout();
            // 
            // textBoxM
            // 
            textBoxM.Location = new Point(254, 17);
            textBoxM.Name = "textBoxM";
            textBoxM.Size = new Size(46, 23);
            textBoxM.TabIndex = 2;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(235, 20);
            label2.Name = "label2";
            label2.Size = new Size(13, 15);
            label2.TabIndex = 6;
            label2.Text = "x";
            // 
            // textBoxN
            // 
            textBoxN.Location = new Point(182, 17);
            textBoxN.Name = "textBoxN";
            textBoxN.Size = new Size(47, 23);
            textBoxN.TabIndex = 1;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(23, 20);
            label1.Name = "label1";
            label1.Size = new Size(127, 15);
            label1.TabIndex = 3;
            label1.Text = "Размерность массива";
            // 
            // textBoxK
            // 
            textBoxK.Enabled = false;
            textBoxK.Location = new Point(541, 20);
            textBoxK.Name = "textBoxK";
            textBoxK.Size = new Size(67, 23);
            textBoxK.TabIndex = 0;
            // 
            // label3
            // 
            label3.Location = new Point(322, 16);
            label3.Name = "label3";
            label3.Size = new Size(197, 35);
            label3.TabIndex = 8;
            label3.Text = "Количество нечетных элементов на четных местах";
            // 
            // btnExit
            // 
            btnExit.Location = new Point(501, 415);
            btnExit.Name = "btnExit";
            btnExit.Size = new Size(107, 23);
            btnExit.TabIndex = 6;
            btnExit.Text = "Выход";
            btnExit.UseVisualStyleBackColor = true;
            btnExit.Click += btnExit_Click;
            // 
            // btnOutputMatrix
            // 
            btnOutputMatrix.Location = new Point(307, 415);
            btnOutputMatrix.Name = "btnOutputMatrix";
            btnOutputMatrix.Size = new Size(122, 23);
            btnOutputMatrix.TabIndex = 4;
            btnOutputMatrix.Text = "Вывод матрицы";
            btnOutputMatrix.UseVisualStyleBackColor = true;
            btnOutputMatrix.Click += btnOutputMatrix_Click;
            // 
            // btnCreateMatrix
            // 
            btnCreateMatrix.Location = new Point(156, 415);
            btnCreateMatrix.Name = "btnCreateMatrix";
            btnCreateMatrix.Size = new Size(134, 23);
            btnCreateMatrix.TabIndex = 3;
            btnCreateMatrix.Text = "Создание матрицы";
            btnCreateMatrix.UseVisualStyleBackColor = true;
            btnCreateMatrix.Click += btnCreateMatrix_Click;
            // 
            // btnClear
            // 
            btnClear.Location = new Point(23, 415);
            btnClear.Name = "btnClear";
            btnClear.Size = new Size(127, 23);
            btnClear.TabIndex = 5;
            btnClear.Text = "Очистка данных";
            btnClear.UseVisualStyleBackColor = true;
            btnClear.Click += btnClear_Click;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(648, 450);
            Controls.Add(btnClear);
            Controls.Add(btnExit);
            Controls.Add(btnOutputMatrix);
            Controls.Add(btnCreateMatrix);
            Controls.Add(textBoxK);
            Controls.Add(label3);
            Controls.Add(textBoxM);
            Controls.Add(label2);
            Controls.Add(textBoxN);
            Controls.Add(label1);
            Name = "Form1";
            Text = "Form1";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private TextBox textBoxM;
        private Label label2;
        private TextBox textBoxN;
        private Label label1;
        private TextBox textBoxK;
        private Label label3;
        private Button btnExit;
        private Button btnOutputMatrix;
        private Button btnCreateMatrix;
        private Button btnClear;
    }
}