namespace Пр4_2_5_Стынгач
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        // Объявление двумерного массива текстовых полей и переменных для хранения размеров матрицы.
        private TextBox[,] tt = new TextBox[0, 0];
        private int n;
        private int m;

        // Создание матрицы текстовых полей при нажатии кнопки "Создать матрицу".
        private void btnCreateMatrix_Click(object sender, EventArgs e)
        {
            // Получение размеров матрицы из текстовых полей.
            int n = Convert.ToInt32(textBoxN.Text);
            int m = Convert.ToInt32(textBoxM.Text);

            // Инициализация массива текстовых полей с размерами n x m.
            tt = new TextBox[n, m];

            // Создание и размещение текстовых полей на форме.
            for (int i = 0; i < n; i++)
            {
                for (int j = 0; j < m; j++)
                {
                    tt[i, j] = new TextBox();

                    // Установка имени и размера для каждого текстового поля.
                    tt[i, j].Name = "tt" + (i).ToString() + (j).ToString();
                    tt[i, j].Size = new Size(40, 30);

                    // Расположение текстовых полей на форме.
                    tt[i, j].Location = new System.Drawing.Point(50 + j * 50, 70 + i * 30);
                    Controls.Add(tt[i, j]);
                }
            }
        }

        // Обработка нажатия кнопки "Вывести матрицу".
        private void btnOutputMatrix_Click(object sender, EventArgs e)
        {
            int n = Convert.ToInt32(textBoxN.Text);
            int m = Convert.ToInt32(textBoxM.Text);
            int k = 0;

            int[,] aa = new int[n, m];
            for (int i = 0; i < n; i++)
            {
                for (int j = 0; j < m; j++)
                {
                    // Заполнение двумерного массива данными из текстовых полей.
                    aa[i, j] = Convert.ToInt32(tt[i, j].Text);

                    // Подсчет условий (нечетное значение и сумма индексов четная).
                    if (aa[i, j] % 2 != 0 && (i + j) % 2 == 0)
                        k++;
                }
                // Вывод значения счетчика в текстовое поле.
                textBoxK.Text = Convert.ToString(k); 
            }
        }

        // Обработка нажатия кнопки "Очистить".
        private void btnClear_Click(object sender, EventArgs e)
        {
            int n = Convert.ToInt32(textBoxN.Text);
            int m = Convert.ToInt32(textBoxM.Text);

            // Удаление всех текстовых полей с формы.
            for (int i = 0; i < n; i++)
            {
                for (int j = 0; j < m; j++)
                {
                    this.Controls.Remove(tt[i, j]);
                }
            }

            // Очистка текстовых полей с размерами матрицы и счетчиком.
            textBoxN.Text = "";
            textBoxM.Text = "";
            textBoxK.Text = "";
        }

        // Обработка нажатия кнопки "Выход".
        private void btnExit_Click(object sender, EventArgs e)
        {
            // Закрытие приложения.
            Close(); 
        }
    }
}
