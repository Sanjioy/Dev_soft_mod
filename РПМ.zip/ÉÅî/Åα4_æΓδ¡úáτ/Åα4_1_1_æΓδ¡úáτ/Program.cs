﻿using System;

class Program
{
    static void Main()
    {
        double[] numbers = { 1.2, 3.4, 5.6, 7.8, 9.0, 11.1, 13.2, 15.3, 17.4, 19.5 };

        Console.WriteLine("Исходный массив:");
        PrintArray(numbers);

        InvertArray(numbers);

        Console.WriteLine("\nИнвертированный массив:");
        PrintArray(numbers);
    }

    // Метод инверсии массива без использования Array.Reverse.
    static void InvertArray(double[] arr)
    {
        int length = arr.Length;
        for (int i = 0; i < length / 2; i++)
        {
            // Обмен значениями элементов для инверсии.
            double temp = arr[i];
            arr[i] = arr[length - i - 1];
            arr[length - i - 1] = temp;
        }
    }

    static void PrintArray(double[] arr)
    {
        // Перебор и вывод элементов массива.
        foreach (var num in arr)
        {
            Console.Write(num + "; ");
        }
        Console.WriteLine();
    }
}
