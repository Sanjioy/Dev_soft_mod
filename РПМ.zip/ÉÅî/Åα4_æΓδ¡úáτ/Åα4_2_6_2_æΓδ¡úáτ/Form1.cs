namespace Пр4_2_6_2_Стынгач
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        // Объявление двумерного массива текстовых полей и переменных для хранения размеров матрицы.
        private TextBox[,] tt = new TextBox[0, 0];
        private int n;
        private int m;

        private void btnCreateMatrix_Click(object sender, EventArgs e)
        {
            // Получение размеров матрицы из текстовых полей.
            int n = Convert.ToInt32(textBoxN.Text);
            int m = Convert.ToInt32(textBoxM.Text);

            // Инициализация массива текстовых полей с размерами n x m.
            tt = new TextBox[n, m];

            // Создание и размещение текстовых полей на форме.
            for (int i = 0; i < n; i++)
            {
                for (int j = 0; j < m; j++)
                {
                    tt[i, j] = new TextBox();

                    // Установка имени и размера для каждого текстового поля.
                    tt[i, j].Name = "tt" + (i).ToString() + (j).ToString();
                    tt[i, j].Size = new Size(40, 30);

                    // Расположение текстовых полей на форме.
                    tt[i, j].Location = new System.Drawing.Point(50 + j * 50, 70 + i * 30);
                    Controls.Add(tt[i, j]);
                }
            }
        }

        private void btnOutputMatrix_Click(object sender, EventArgs e)
        {
            int n = Convert.ToInt32(textBoxN.Text);
            int m = Convert.ToInt32(textBoxM.Text);
            int count = 0;

            // Подсчет положительных элементов, превышающих 10.
            for (int i = 0; i < n; i++)
            {
                for (int j = 0; j < m; j++)
                {
                    int value;
                    if (int.TryParse(tt[i, j].Text, out value) && value > 10)
                    {
                        count++;
                    }
                }
            }
            // Вывод значения счетчика в textBoxK.
            textBoxK.Text = Convert.ToString(count);
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            int n = Convert.ToInt32(textBoxN.Text);
            int m = Convert.ToInt32(textBoxM.Text);

            // Удаление всех текстовых полей с формы.
            for (int i = 0; i < n; i++)
            {
                for (int j = 0; j < m; j++)
                {
                    this.Controls.Remove(tt[i, j]);
                }
            }

            // Очистка текстовых полей с размерами матрицы и счетчиком.
            textBoxN.Text = "";
            textBoxM.Text = "";
            textBoxK.Text = "";
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            // Закрытие приложения.
            Close();
        }
    }
}