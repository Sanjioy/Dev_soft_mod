﻿namespace Пр4_2_6_2_Стынгач
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            btnClear = new Button();
            btnExit = new Button();
            btnOutputMatrix = new Button();
            btnCreateMatrix = new Button();
            textBoxK = new TextBox();
            label3 = new Label();
            textBoxM = new TextBox();
            label2 = new Label();
            textBoxN = new TextBox();
            label1 = new Label();
            SuspendLayout();
            // 
            // btnClear
            // 
            btnClear.Location = new Point(19, 422);
            btnClear.Name = "btnClear";
            btnClear.Size = new Size(127, 23);
            btnClear.TabIndex = 6;
            btnClear.Text = "Очистка данных";
            btnClear.UseVisualStyleBackColor = true;
            btnClear.Click += btnClear_Click;
            // 
            // btnExit
            // 
            btnExit.Location = new Point(497, 422);
            btnExit.Name = "btnExit";
            btnExit.Size = new Size(107, 23);
            btnExit.TabIndex = 7;
            btnExit.Text = "Выход";
            btnExit.UseVisualStyleBackColor = true;
            btnExit.Click += btnExit_Click;
            // 
            // btnOutputMatrix
            // 
            btnOutputMatrix.Location = new Point(303, 422);
            btnOutputMatrix.Name = "btnOutputMatrix";
            btnOutputMatrix.Size = new Size(128, 23);
            btnOutputMatrix.TabIndex = 5;
            btnOutputMatrix.Text = "Подсчет количества";
            btnOutputMatrix.UseVisualStyleBackColor = true;
            btnOutputMatrix.Click += btnOutputMatrix_Click;
            // 
            // btnCreateMatrix
            // 
            btnCreateMatrix.Location = new Point(152, 422);
            btnCreateMatrix.Name = "btnCreateMatrix";
            btnCreateMatrix.Size = new Size(134, 23);
            btnCreateMatrix.TabIndex = 3;
            btnCreateMatrix.Text = "Создание матрицы";
            btnCreateMatrix.UseVisualStyleBackColor = true;
            btnCreateMatrix.Click += btnCreateMatrix_Click;
            // 
            // textBoxK
            // 
            textBoxK.Enabled = false;
            textBoxK.Location = new Point(563, 6);
            textBoxK.Name = "textBoxK";
            textBoxK.Size = new Size(67, 23);
            textBoxK.TabIndex = 0;
            // 
            // label3
            // 
            label3.Location = new Point(270, 9);
            label3.Name = "label3";
            label3.Size = new Size(300, 20);
            label3.TabIndex = 0;
            label3.Text = "Количество положительных элементов больше 10:";
            // 
            // textBoxM
            // 
            textBoxM.Location = new Point(218, 6);
            textBoxM.Name = "textBoxM";
            textBoxM.Size = new Size(46, 23);
            textBoxM.TabIndex = 2;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(199, 9);
            label2.Name = "label2";
            label2.Size = new Size(13, 15);
            label2.TabIndex = 13;
            label2.Text = "x";
            // 
            // textBoxN
            // 
            textBoxN.Location = new Point(146, 6);
            textBoxN.Name = "textBoxN";
            textBoxN.Size = new Size(47, 23);
            textBoxN.TabIndex = 1;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(7, 9);
            label1.Name = "label1";
            label1.Size = new Size(127, 15);
            label1.TabIndex = 0;
            label1.Text = "Размерность массива";
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(639, 457);
            Controls.Add(textBoxK);
            Controls.Add(label3);
            Controls.Add(textBoxM);
            Controls.Add(label2);
            Controls.Add(textBoxN);
            Controls.Add(label1);
            Controls.Add(btnClear);
            Controls.Add(btnExit);
            Controls.Add(btnOutputMatrix);
            Controls.Add(btnCreateMatrix);
            Name = "Form1";
            Text = "Form1";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button btnClear;
        private Button btnExit;
        private Button btnOutputMatrix;
        private Button btnCreateMatrix;
        private TextBox textBoxK;
        private Label label3;
        private TextBox textBoxM;
        private Label label2;
        private TextBox textBoxN;
        private Label label1;
    }
}