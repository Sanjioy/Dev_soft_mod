namespace Пр4_2_6_1_Стынгач
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnSetArray_Click(object sender, EventArgs e)
        {
            // Получение значений из текстовых полей.
            int n = Convert.ToInt32(textBoxN.Text);
            int m = Convert.ToInt32(textBoxM.Text);

            // Добавление столбцов в dataGridView dGVSourceArray.
            for (int i = 0; i <= m; i++)
            {
                dGVSourceArray.Columns.Add("", "");
                // Установка заголовков столбцов, кроме первого.
                if (i > 0)
                    dGVSourceArray.Columns[i].HeaderText = Convert.ToString(i - 1);
                // Установка ширины столбцов.
                dGVSourceArray.Columns[i].Width = 40;
            }

            // Добавление строк в dataGridView dGVSourceArray.
            for (int i = 0; i < n; i++)
            {
                dGVSourceArray.Rows.Add(Convert.ToString(i), "");
            }

            // Скрыть кнопку "Задать массив" после ее срабатывания
            btnSetArray.Visible = false;
        }

        private void btnOutputArray_Click(object sender, EventArgs e)
        {
            int n = Convert.ToInt32(textBoxN.Text);
            int m = Convert.ToInt32(textBoxM.Text);
            int count = 0;

            // Проходим по ячейкам DataGridView и считаем положительные элементы больше 10
            foreach (DataGridViewRow row in dGVSourceArray.Rows)
            {
                foreach (DataGridViewCell cell in row.Cells)
                {
                    int value;
                    if (cell.Value != null && int.TryParse(cell.Value.ToString(), out value))
                    {
                        if (value > 10)
                        {
                            count++;
                        }
                    }
                }
            }

            // Вывод значения счетчика в textBoxK.
            textBoxK.Text = Convert.ToString(count);

            // Скрыть кнопку "Вывод массива" после ее срабатывания
            btnOutputArray.Visible = false;
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}