﻿namespace Пр4_2_6_1_Стынгач
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            dGVSourceArray = new DataGridView();
            textBoxM = new TextBox();
            label2 = new Label();
            textBoxN = new TextBox();
            label1 = new Label();
            textBoxK = new TextBox();
            label3 = new Label();
            btnExit = new Button();
            btnOutputArray = new Button();
            btnSetArray = new Button();
            ((System.ComponentModel.ISupportInitialize)dGVSourceArray).BeginInit();
            SuspendLayout();
            // 
            // dGVSourceArray
            // 
            dGVSourceArray.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dGVSourceArray.Location = new Point(12, 54);
            dGVSourceArray.Name = "dGVSourceArray";
            dGVSourceArray.RowTemplate.Height = 25;
            dGVSourceArray.Size = new Size(622, 319);
            dGVSourceArray.TabIndex = 4;
            // 
            // textBoxM
            // 
            textBoxM.Location = new Point(222, 12);
            textBoxM.Name = "textBoxM";
            textBoxM.Size = new Size(46, 23);
            textBoxM.TabIndex = 2;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(203, 15);
            label2.Name = "label2";
            label2.Size = new Size(13, 15);
            label2.TabIndex = 0;
            label2.Text = "x";
            // 
            // textBoxN
            // 
            textBoxN.Location = new Point(150, 12);
            textBoxN.Name = "textBoxN";
            textBoxN.Size = new Size(47, 23);
            textBoxN.TabIndex = 1;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(11, 15);
            label1.Name = "label1";
            label1.Size = new Size(127, 15);
            label1.TabIndex = 0;
            label1.Text = "Размерность массива";
            // 
            // textBoxK
            // 
            textBoxK.Enabled = false;
            textBoxK.Location = new Point(567, 12);
            textBoxK.Name = "textBoxK";
            textBoxK.Size = new Size(67, 23);
            textBoxK.TabIndex = 0;
            // 
            // label3
            // 
            label3.Location = new Point(274, 15);
            label3.Name = "label3";
            label3.Size = new Size(300, 20);
            label3.TabIndex = 0;
            label3.Text = "Количество положительных элементов больше 10:";
            // 
            // btnExit
            // 
            btnExit.Location = new Point(458, 394);
            btnExit.Name = "btnExit";
            btnExit.Size = new Size(130, 23);
            btnExit.TabIndex = 6;
            btnExit.Text = "Выход";
            btnExit.UseVisualStyleBackColor = true;
            btnExit.Click += btnExit_Click;
            // 
            // btnOutputArray
            // 
            btnOutputArray.Location = new Point(258, 394);
            btnOutputArray.Name = "btnOutputArray";
            btnOutputArray.Size = new Size(154, 23);
            btnOutputArray.TabIndex = 5;
            btnOutputArray.Text = "Найти количество";
            btnOutputArray.UseVisualStyleBackColor = true;
            btnOutputArray.Click += btnOutputArray_Click;
            // 
            // btnSetArray
            // 
            btnSetArray.Location = new Point(53, 394);
            btnSetArray.Name = "btnSetArray";
            btnSetArray.Size = new Size(180, 23);
            btnSetArray.TabIndex = 3;
            btnSetArray.Text = "Задать массив";
            btnSetArray.UseVisualStyleBackColor = true;
            btnSetArray.Click += btnSetArray_Click;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(658, 450);
            Controls.Add(btnExit);
            Controls.Add(btnOutputArray);
            Controls.Add(btnSetArray);
            Controls.Add(textBoxK);
            Controls.Add(label3);
            Controls.Add(dGVSourceArray);
            Controls.Add(textBoxM);
            Controls.Add(label2);
            Controls.Add(textBoxN);
            Controls.Add(label1);
            Name = "Form1";
            Text = "Form1";
            ((System.ComponentModel.ISupportInitialize)dGVSourceArray).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private DataGridView dGVSourceArray;
        private TextBox textBoxM;
        private Label label2;
        private TextBox textBoxN;
        private Label label1;
        private TextBox textBoxK;
        private Label label3;
        private Button btnExit;
        private Button btnOutputArray;
        private Button btnSetArray;
    }
}