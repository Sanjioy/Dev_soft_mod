﻿using System;
using System.Linq;

class Program
{
    static void Main()
    {
        double[] numbers = { 5.0, 7.0, 10.0, 8.0, 6.0, 12.0, 9.0, 11.0, 15.0, 17.0, 20.0 };

        Console.WriteLine("Исходный массив:");
        PrintArray(numbers);

        TransformArray(numbers);

        Console.WriteLine("\nПреобразованный массив:");
        PrintArray(numbers);
    }

    static void TransformArray(double[] arr)
    {
        // Находим максимальное значение в массиве.
        double max = arr.Max();
        // Определяем порог для 20% от максимального значения.
        double threshold = max * 0.2;

        // Индекс для вставки элементов, соответствующих условию, в начало массива.
        int insertionIndex = 0;

        for (int i = 0; i < arr.Length; i++)
        {
            if (Math.Abs(arr[i] - max) <= threshold)
            {
                if (i != insertionIndex)
                {
                    double temp = arr[i];

                    // Сдвигаем элементы вправо, начиная от индекса вставки до текущего индекса.
                    for (int j = i; j > insertionIndex; j--)
                    {
                        arr[j] = arr[j - 1];
                    }

                    // Вставляем сохраненный элемент на позицию вставки.
                    arr[insertionIndex] = temp;
                }

                insertionIndex++;
            }
        }
    }

    static void PrintArray(double[] arr)
    {
        foreach (var num in arr)
        {
            Console.Write(num + "; ");
        }
        Console.WriteLine();
    }
}
