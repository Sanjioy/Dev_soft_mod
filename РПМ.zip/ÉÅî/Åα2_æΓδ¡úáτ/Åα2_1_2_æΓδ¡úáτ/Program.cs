﻿using System;

namespace Пр2_1_2_Стынгач
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.Write("Введите eps: ");
            double eps = Convert.ToDouble(Console.ReadLine());
            Console.Write("Введите x: ");
            int x = Convert.ToInt32(Console.ReadLine());
            double m = 1;
            double s = 0;
            int i = 1;
            do
            {
                m = (Math.Pow((-1), i - 1) * i) / Math.Pow(x, i);
                s = s + m;
                i++;
            } while (Math.Abs(m) > eps);
            Console.WriteLine("S = " + s);
        }
    }
}
