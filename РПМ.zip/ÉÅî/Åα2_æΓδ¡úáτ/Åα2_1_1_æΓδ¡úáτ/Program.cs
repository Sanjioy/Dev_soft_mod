﻿using System;

namespace Пр2_1_Стынгач
{
    class Program
    {

        static void Main(string[] args)
        {
            int number = 2;
            for (int i = 0; i <= 20; i++)
            {
                long result = (long)Math.Pow(number, i);
                Console.WriteLine($"{number} в степени {i} = {result}");
            }
        }
    }
}
