﻿/*Начав тренировки, лыжник в первый день пробежал 10 км. 
Каждый следующий день он увеличивал пробег на 10% от пробега предыдущего дня. 
Определить в какой день суммарный пробег за все дни превысит 100 км.*/
using System;

namespace Пр2_1_3_Стынгач
{
    class Program
    {
        static void Main(string[] args)
        {
            double initialDistance = 10; //начальный
            double totalDistance = 0; //общий
            double new_day;
            int count = 0;
            while (totalDistance <= 100)
            {
                totalDistance += initialDistance;
                new_day = initialDistance * 0.1;
                initialDistance += new_day;
                count++;
                Console.Write("Пробег на следующий день: " + Math.Round(initialDistance, 2) + " ");
                Console.WriteLine("Сумма на " + count + " день: " + Math.Round(totalDistance, 2) + " км");
            }
            Console.WriteLine("Суммарный пробег превысит 100 км на " + count + " день");
        }
    }
}
