﻿/*Одноклеточная амеба каждые 3 часа делится на 2 клетки. 
Определить, сколько клеток будет через 3, 6, 9, ..., 24 часа, 
если первоначально была одна амеба. 
Решить задачу используя циклическую конструкцию.*/
using System;

namespace Пр2_1_4_Стынгач
{
    class Program
    {
        static void Main(string[] args)
        {
            int hours = 24;
            int interval = 3;
            int initialCells = 1;
            for (int i = interval; i <= hours; i += interval)
            {
                int cells = initialCells * (int)Math.Pow(2, (i / interval));
                Console.WriteLine("{0}hour(s): {1} cells", i, cells);
            }
        }
    }
}
