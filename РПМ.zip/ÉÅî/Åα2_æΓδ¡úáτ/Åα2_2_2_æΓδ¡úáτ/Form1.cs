namespace Пр2_2_2_Стынгач
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            textBox1.KeyPress += TextBox_KeyPress;
            textBox2.KeyPress += TextBox_KeyPress;
            textBox3.KeyPress += TextBox_KeyPress;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (textBox1.Text.Length == 0 || textBox2.Text.Length == 0 || textBox3.Text.Length == 0)
            {
                MessageBox.Show("Введите значения", "Сообщение", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }
            double x0, xk, dx;
            if (!double.TryParse(textBox1.Text, out x0) || !double.TryParse(textBox2.Text, out xk) || !double.TryParse(textBox3.Text, out dx))
            {
                MessageBox.Show("Некорректный ввод чисел", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
            textBox4.Text = "Работу выполнил ст. Иванов М.А." + Environment.NewLine;
            double x = x0;
            while (x <= (xk + dx / 2))
            {
                double y = Math.Pow((Math.Log(Math.Sin(Math.Pow(x, 3) + 0.0025))), 3 / 2) + 0.8 * Math.Pow(10, -3);
                textBox4.Text = "x = " + Convert.ToString(x) + "; y = " + Convert.ToString(y) + Environment.NewLine;
                x = x + dx;
            }
        }
        
        private void TextBox_KeyPress(object sender, KeyPressEventArgs e)
        {
            // Получаем ссылку на textBox, генерировавший событие KeyPress.
            TextBox textBox = (TextBox)sender; 

            if ((e.KeyChar >= '0' && e.KeyChar <= '9') || e.KeyChar == ',' || Char.IsControl(e.KeyChar))
            {
                // Разрешить ввод цифр, запятой (как разделитель) и управляющих клавиш.
                if (e.KeyChar == ',' && textBox.Text.Contains(","))
                {
                    // Если в тексте уже есть запятая, игнорировать ввод еще одной.
                    e.Handled = true;
                }
            }
            else
            {
                // Запретить ввод других символов.
                e.Handled = true;
            }
        }
    }
}
