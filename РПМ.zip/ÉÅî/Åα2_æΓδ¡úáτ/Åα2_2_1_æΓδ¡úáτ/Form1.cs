namespace Пр2_2_1_Стынгач
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (textBox1.Text.Length == 0 )
            {
                MessageBox.Show("Введите значения", "Сообщение", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
            double x0 = Convert.ToDouble(textBox1.Text);
            double xk = Convert.ToDouble(textBox2.Text);
            double dx = Convert.ToDouble(textBox3.Text);
            double a = Convert.ToDouble(textBox4.Text);
            textBox5.Text = "Работу выполнил ст. Иванов М.А." + Environment.NewLine;
            double x = x0;
            while (x <= (xk + dx / 2))
            {
                double y = a * Math.Log(x);
                textBox5.Text = "x = " + Convert.ToString(x) + "; y = " + Convert.ToString(y) + Environment.NewLine;
                x = x + dx;
            }
        }

        private void textBox1_KeyPress(object sender, KeyPressEventArgs e)   
        {
            // Цифры.
            if ((e.KeyChar >= '0') && (e.KeyChar <= '9'))
            {
                return;
            }
            // Точку заменим запятой.
            if (e.KeyChar == '.')
            {
                e.KeyChar = ',';
            }
            if (e.KeyChar ==  ',')
            {
                if (textBox1.Text.IndexOf(',') != -1)
                {
                    e.Handled = true;
                }
                return;
            }
            // Управляющие клавиши <Backspace>, <Enter> и т.д.
            if (Char.IsControl(e.KeyChar))
            {
                return;
            }
            e.Handled = true;        
        }
        
    }
}