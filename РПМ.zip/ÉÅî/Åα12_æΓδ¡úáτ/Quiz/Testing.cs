﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Task;

namespace Quiz
{
    class Testing
    {
        // Выполняет тестирование и возвращает результат в виде строки.
        public string DoTesting()
        {
            // Переменная для хранения общего балла по всем вопросам.
            int SumBal = 0;
            // Переменная для хранения ответа пользователя на текущий вопрос.
            int ans = 0; 

            // Перебор всех вопросов из коллекции AllQuestions.
            foreach (Task.SingleTest p in Task.Task.AllQuestions)
            {
                Console.WriteLine("//////////////////////////");
                // Вывод текста вопроса в консоль.
                Console.WriteLine(p.Question); 
                Console.WriteLine("//////////////////////////");
                Console.WriteLine("1. " + p.Answers[0]); 
                Console.WriteLine("2. " + p.Answers[1]); 
                Console.WriteLine("3. " + p.Answers[2]);

                // Флаг для проверки корректности ввода ответа пользователем
                bool validInput = false; 

                // Цикл, продолжающийся до тех пор, пока не будет получен корректный ответ от пользователя.
                do
                {
                    try
                    {
                        Console.Write("Выберите номер ответа > ");
                        ans = Convert.ToInt32(Console.ReadLine()); 

                        // Проверка на корректность введенного числа
                        if (ans >= 1 && ans <= 3)
                        {
                            validInput = true; 
                        }
                        else
                        {
                            Console.WriteLine("Введите корректный номер ответа (1, 2 или 3).");
                        }
                    }
                    catch (FormatException)
                    {
                        // В случае ошибки формата числа.
                        Console.WriteLine("Введите корректное число."); 
                    }
                    catch (OverflowException)
                    {
                        // В случае переполнения.
                        Console.WriteLine("Введенное число слишком большое или слишком маленькое."); 
                    }
                } while (!validInput);

                // Добавляем баллы за текущий вопрос к общему количеству баллов.
                SumBal += p.Balls[ans - 1]; 
            }

            // Возвращаем сообщение о результате теста на основе общего балла.
            return Result.Result.GetMessage(SumBal); 
        }
    }
}
