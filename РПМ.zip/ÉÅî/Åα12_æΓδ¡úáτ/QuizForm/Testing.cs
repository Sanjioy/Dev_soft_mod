﻿using Result; // Подключение пространства имен Result, возможно, содержащего классы для вывода результатов тестирования
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Task;

namespace QuizForm
{
    class Testing
    {
        // Список вопросов для тестирования.
        private List<SingleTest> questions;
        // Индекс текущего вопроса.
        private int currentQuestionIndex;
        // Общее количество баллов.
        private int totalPoints; 

        public Testing()
        {
            // Инициализация списка вопросов из источника.
            questions = Task.Task.AllQuestions; 
            currentQuestionIndex = 0; 
            totalPoints = 0; 
        }

        // Проверка наличия следующего вопроса для тестирования.
        public bool HasNextQuestion()
        {
            // Возвращает true, если есть еще вопросы для теста.
            return currentQuestionIndex < questions.Count; 
        }

        // Получение следующего вопроса для тестирования.
        public SingleTest GetNextQuestion()
        {
            if (HasNextQuestion())
            {
                // Получение следующего вопроса.
                SingleTest nextQuestion = questions[currentQuestionIndex]; 
                currentQuestionIndex++; 
                return nextQuestion;
            }
            return null;
        }

        // Обработка ответа пользователя на вопрос и начисление баллов.
        public void ProcessAnswer(int selectedAnswerIndex)
        {
            if (selectedAnswerIndex >= 0 && selectedAnswerIndex < questions[currentQuestionIndex - 1].Balls.Count)
            {
                // Получение баллов за ответ.
                int points = questions[currentQuestionIndex - 1].Balls[selectedAnswerIndex];
                // Добавление баллов к общему количеству.
                totalPoints += points; 
            }
        }

        // Получение результата теста в виде сообщения
        public string GetQuizResult()
        {
            // Возврат сообщения о результате на основе общего количества баллов.
            return Result.Result.GetMessage(totalPoints); 
        }
    }
}
