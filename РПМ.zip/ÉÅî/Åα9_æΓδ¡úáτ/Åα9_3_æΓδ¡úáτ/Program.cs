﻿using System;

namespace Пр9_3_Стынгач
{
    // Абстрактный класс Figura
    public abstract class Figura
    {
        // Абстрактный метод для вычисления площади
        public abstract double Area();
    }

    // Класс Rectangle (прямоугольник) наследуется от Figura
    public class Rectangle : Figura
    {
        // Поля для хранения ширины и высоты прямоугольника
        private double width;
        private double height;

        // Конструктор прямоугольника
        public Rectangle(double width, double height)
        {
            this.width = width;
            this.height = height;
        }

        // Переопределение метода Area для прямоугольника
        public override double Area()
        {
            return width * height;
        }
    }

    // Класс Circle (круг) наследуется от Figura
    public class Circle : Figura
    {
        // Поле для хранения радиуса круга
        private double radius;

        // Конструктор круга
        public Circle(double radius)
        {
            this.radius = radius;
        }

        // Переопределение метода Area для круга
        public override double Area()
        {
            return Math.PI * radius * radius;
        }
    }

    class Program
    {
        static void Main()
        {
            // Пример использования классов
            Rectangle rectangle = new Rectangle(5, 10);
            Circle circle = new Circle(7);

            Console.WriteLine("Площадь прямоугольника: " + rectangle.Area());
            Console.WriteLine("Площадь круга: " + circle.Area());
        }
    }
}

