﻿using System;

namespace Пр9_1_Стынгач
{
    class Program
    {
        // Метод для получения модели автомобиля в зависимости от введенной пользователем марки.
        static Avto GetAvto()
        {
            Console.Write("Введите марку автомобиля (Vaz, Maz, BMV): ");
            // Считываем, что вводит пользователь и приводим к нижнему регистру.
            string mod = Console.ReadLine().ToLower();
            switch (mod)
            {
                // Возвращаем модель соответствующего класса в зависимости от введенной марки.
                case "vaz": return new Vaz();
                case "maz": return new Maz();
                case "bmv": return new BMV();
                // По умолчанию возвращаем Maz.
                default: return new Maz();
            }
        }
        
        static void Main()
        {
            // Получаем автомобиль с помощью метода GetAvto.
            Avto myAvto = GetAvto();

            // Вызываем методы Drive и Show для полученного автомобиля.
            myAvto.Drive();
            myAvto.Show();
            Console.ReadKey();
        }
    }
}