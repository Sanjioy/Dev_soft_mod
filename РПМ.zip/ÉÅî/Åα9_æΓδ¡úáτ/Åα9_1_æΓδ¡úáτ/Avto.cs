﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Пр9_1_Стынгач
{
    public abstract class Avto
    {
        protected string dop;
        protected string model;
        protected int speed;
        protected int power;
        protected double fuel;

        public abstract void Drive();

        public void Show()
        {
            Console.WriteLine("Модель {0}, скорость {1}, двигатель {2}, мощность {3} лош. сил, расход топлива - {4}.", model, speed, dop, power, fuel);
        }

        interface ITurbo
        {
            void Turbo();
        }
        interface IEco
        {
            void Eco();
        }
    }
}