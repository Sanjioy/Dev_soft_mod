﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Пр9_1_Стынгач
{
    public interface ITurbo
    {
        void Turbo();
    }
}