﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Пр9_1_Стынгач
{
    public class Vaz : Avto, IEco
    {
        public override void Drive()
        {
            model = "vaz2107";
            speed = 70;
            Eco();
            power = 140;
            fuel = 9.7;
        }

        public void Eco()
        {
            dop = "экологичный";
        }
    }
}