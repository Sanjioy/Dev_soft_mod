﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Пр9_1_Стынгач
{
    public class BMV : Avto, ITurbo, IEco
    {
        public override void Drive()
        {
            model = "BMVe39";
            speed = 228;
            Turbo();
            power = 170;
            fuel = 13.5;

        }

        public void Turbo()
        {
            dop = "турбо ";
        }

        public void Eco()
        {
            dop = "экологичный";
        }
    }
}