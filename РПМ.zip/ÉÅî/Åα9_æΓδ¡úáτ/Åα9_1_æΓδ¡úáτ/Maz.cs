﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Пр9_1_Стынгач
{
    public class Maz : Avto, ITurbo
    {
        public override void Drive()
        {
            model = "Maz200";
            speed = 90;
            Turbo();
            power = 110;
            fuel = 38;
        }

        public void Turbo()
        {
            dop = "турбо";
        }
    }
}