﻿using System;
using System.Collections.Generic;

namespace Пр9_2_Стынгач
{
    class Program
    {
        static void Main()
        {
            // Для корректного отображения информации.
            Console.OutputEncoding = System.Text.Encoding.UTF8;
            // Создание экземпляра обобщенного класса CompInv, способного сравнивать объекты типа AutoShop по их стоимости.
            CompInv<AutoShop> cp = new CompInv<AutoShop>();
            // Создание списка объектов типа AutoShop.
            List<AutoShop> dic = new List<AutoShop>();

            // Добавление различных автомобилей в список dic.
            dic.Add(new AutoShop("Toyota Corolla", 180, 300000, 5, 1));
            dic.Add(new AutoShop("Vaz 2114i", 160, 220000, 0, 2));
            dic.Add(new AutoShop("Daewoo Nexia", 140, 260000, 5, 3));
            dic.Add(new AutoShop("Honda Torneo", 220, 400000, 7, 4));
            dic.Add(new AutoShop("Audi R8 Best", 360, 420000, 3, 5));

            // Вывод заголовка для исходного каталога автомобилей.
            Console.WriteLine("Исходный каталог автомобилей: \n");
            // Установка ширины окна консоли.
            Console.WindowWidth = 100;
            // Вывод информации о каждом автомобиле из списка dic.
            foreach (AutoShop a in dic)
                Console.WriteLine(a);

            // Вывод заголовка для отсортированного списка автомобилей.
            Console.WriteLine("\nТеперь автомобили отсортированы по стоимости: \n");
            // Отсортировать список dic с использованием компаратора cp (CompInv).
            dic.Sort(cp);
            // Вывод отсортированной информации о каждом автомобиле из списка dic.
            foreach (AutoShop a in dic)
                Console.WriteLine(a);

            // Ожидание ввода пользователя перед закрытием приложения.
            Console.ReadLine();
        }
    }
}