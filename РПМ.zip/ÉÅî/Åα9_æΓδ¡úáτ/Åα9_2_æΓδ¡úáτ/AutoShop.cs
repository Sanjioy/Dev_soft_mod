﻿using System;
using System.Collections.Generic;

namespace Пр9_2_Стынгач
{
    // Класс, представляющий автомобиль.
    class AutoShop
    {
        // Свойства, описывающие характеристики автомобиля.
        public string CarName { get; set; }
        public int MaxSpeed { get; set; }
        public double Cost { get; set; }
        public byte Discount { get; set; }
        public int ID { get; set; }

        // Конструкторы класса для инициализации свойств автомобиля.
        public AutoShop() { }
        public AutoShop(string CarName, int MaxSpeed, double Cost, byte Discount, int ID)
        {
            this.CarName = CarName;
            this.MaxSpeed = MaxSpeed;
            this.Cost = Cost;
            this.Discount = Discount;
            this.ID = ID;
        }

        // Переопределение метода ToString для корректного отображения информации об автомобиле.
        public override string ToString()
        {
            return String.Format("{4}\tМарка: {0}\tМакс. скорость: {1}\tЦена: {2:C}\tСкидка: {3}%", this.CarName, this.MaxSpeed, this.Cost, this.Discount, this.ID);
        }
    }

    // Класс, реализующий интерфейс IComparer для сравнения объектов типа AutoShop по стоимости.
    class CompInv<T> : IComparer<T> where T : AutoShop
    {
        // Метод Compare сравнивает объекты по их стоимости.
        public int Compare(T x, T y)
        {
            if (x.Cost < y.Cost)
                return 1;
            if (x.Cost > y.Cost)
                return -1;
            else
                return 0;
        }
    }
}