﻿using System;

class Program
{
    static void Main()
    {
        int number1 = 10;
        int number2 = 25;
        int number3 = 17;

        int maxOfTwo = FindMax(number1, number2);
        int maxOfThree = FindMaxOfThree(number1, number2, number3);

        Console.WriteLine($"Наибольшее из трех чисел {number1}, {number2} и {number3} равно {maxOfThree}");
        Console.WriteLine($"Наибольшее из чисел {number1} и {number2} равно {maxOfTwo}");  
    }

    static int FindMax(int a, int b)
    {
        return (a > b) ? a : b;
    }

    static int FindMaxOfThree(int a, int b, int c)
    {
        int maxOfTwo = FindMax(a, b);
        return FindMax(maxOfTwo, c);
    }
}
