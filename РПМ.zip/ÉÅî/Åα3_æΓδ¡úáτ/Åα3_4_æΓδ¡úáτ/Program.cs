﻿using System;

class Program
{
    static void Main()
    {
        int a = 5;
        int b = 8;

        int result = CalculateExpression(a, b);

        Console.WriteLine($"Результат выражения при a = {a} и b = {b} равен {result}");
    }

    static int CalculateExpression(int a, int b)
    {
        int max1 = Math.Max(a, 3 * b + 4);
        int max2 = Math.Max(3 - 2 * a, b - 7);

        return max1 * max2;
    }
}
