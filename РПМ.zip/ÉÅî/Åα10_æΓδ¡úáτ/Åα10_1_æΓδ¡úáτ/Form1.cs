namespace Пр10_1_Стынгач
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        class Животное
        {
            public string n = "???";
            public double w;
            public double w0;

            public void Данные(string n, double w, double w0)
            {
                if (n != "")
                    this.n = n;
                if (w > 0)
                    this.w = w;
                else
                    MessageBox.Show("Вес должен быть задан положительным числом!!!", "Ошибка");
                if (w0 > 0)
                    this.w0 = w0;
                else
                    MessageBox.Show("Прежний вес должен быть задан положительным числом!!!", "Ошибка");
            }
            public void Информация()
            {
                string caption = "Информация о животном";
                string message = "";
                if (Привес(w, w0) > 0)
                {
                    message = "Животное  " + n + " с весом " + w + " кг и прежним весом " + w0
                        + " кг поправилось на  " + Привес(w, w0) + " кг";
                }
                else if (Привес(w, w0) < 0)
                {
                    message = "Животное  " + n + " с весом " + w + " кг и прежним весом " + w0
                        + " кг похудело на " + Math.Abs(Привес(w, w0)) + " кг ";
                }
                else
                {
                    message = "Животное  " + n + " с весом " + w + " кг и прежним весом " + w0
                        + " не изменило свой вес";
                }
                MessageBoxButtons buttons = MessageBoxButtons.OK;
                MessageBox.Show(message, caption, buttons);
            }
            public double Привес(double w, double w0)
            {
                return w - w0;
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string Name;
            double Weight, Weight0;

            Животное животное = new Животное();
            if (textBox1.Text != "" || textBox2.Text != "" || textBox3.Text != "")
            {
                Name = textBox1.Text;
                try
                {
                    Weight = double.Parse(textBox2.Text);
                    Weight0 = double.Parse(textBox3.Text);
                }
                catch (FormatException)
                {
                    MessageBox.Show("Отсутствует, или ошибочный вес (прежний вес) животного!!!", "Ошибка");
                    return;
                }
                животное.Данные(Name, Weight, Weight0);
            }
            животное.Информация();
        }
    }
}