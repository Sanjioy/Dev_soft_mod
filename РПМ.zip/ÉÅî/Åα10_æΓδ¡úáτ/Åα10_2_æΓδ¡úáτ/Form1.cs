using System.Security.Policy;

namespace Пр10_2_Стынгач
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        // Класс Конус.
        public class Cone
        {
            private double radius;
            private double height;

            // Конструктор класса Конус.
            public Cone(double r, double h)
            {
                radius = r;
                height = h;
            }

            // Метод для вычисления объема конуса.
            public double Volume()
            {
                return Math.PI * radius * radius * height / 3.0;
            }

            // Метод для вычисления площади поверхности конуса.
            public double SurfaceArea()
            {
                double baseArea = Math.PI * radius * radius;
                double sideArea = Math.PI * radius * Math.Sqrt(radius * radius + height * height);
                return baseArea + sideArea;
            }
        }

        private void CalculateButton_Click(object sender, EventArgs e)
        {
            // Получаем значения радиуса и высоты из текстовых полей.
            if (double.TryParse(radiusTextBox.Text, out double radius) &&
                double.TryParse(heightTextBox.Text, out double height))
            {
                // Создаем экземпляр класса Конус.
                Cone cone = new Cone(radius, height);

                // Вычисляем объем и площадь поверхности конуса.
                double volume = cone.Volume();
                double surfaceArea = cone.SurfaceArea();

                // Выводим результаты в текстовые поля (2 числа после запятой).
                volumeTextBox.Text = volume.ToString("F2");
                surfaceAreaTextBox.Text = surfaceArea.ToString("F2");
            }
            else
            {
                MessageBox.Show("Пожалуйста, введите корректные значения для радиуса и высоты.");
            }
        }
    }
}