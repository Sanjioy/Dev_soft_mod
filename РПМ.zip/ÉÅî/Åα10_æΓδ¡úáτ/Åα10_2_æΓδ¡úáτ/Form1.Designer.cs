﻿namespace Пр10_2_Стынгач
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label1 = new Label();
            radiusTextBox = new TextBox();
            label2 = new Label();
            heightTextBox = new TextBox();
            label3 = new Label();
            volumeTextBox = new TextBox();
            label4 = new Label();
            surfaceAreaTextBox = new TextBox();
            CalculateButton = new Button();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(21, 12);
            label1.Name = "label1";
            label1.Size = new Size(135, 15);
            label1.TabIndex = 0;
            label1.Text = "Введите радиус конуса:";
            // 
            // radiusTextBox
            // 
            radiusTextBox.Location = new Point(162, 9);
            radiusTextBox.Name = "radiusTextBox";
            radiusTextBox.Size = new Size(100, 23);
            radiusTextBox.TabIndex = 1;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(326, 12);
            label2.Name = "label2";
            label2.Size = new Size(136, 15);
            label2.TabIndex = 2;
            label2.Text = "Введите высоту конуса:";
            // 
            // heightTextBox
            // 
            heightTextBox.Location = new Point(468, 9);
            heightTextBox.Name = "heightTextBox";
            heightTextBox.Size = new Size(100, 23);
            heightTextBox.TabIndex = 3;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(67, 56);
            label3.Name = "label3";
            label3.Size = new Size(89, 15);
            label3.TabIndex = 4;
            label3.Text = "Объем конуса:";
            // 
            // volumeTextBox
            // 
            volumeTextBox.Enabled = false;
            volumeTextBox.Location = new Point(162, 53);
            volumeTextBox.Name = "volumeTextBox";
            volumeTextBox.Size = new Size(100, 23);
            volumeTextBox.TabIndex = 5;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(285, 56);
            label4.Name = "label4";
            label4.Size = new Size(177, 15);
            label4.TabIndex = 6;
            label4.Text = "Площадь поверхности конуса:";
            // 
            // surfaceAreaTextBox
            // 
            surfaceAreaTextBox.Enabled = false;
            surfaceAreaTextBox.Location = new Point(468, 53);
            surfaceAreaTextBox.Name = "surfaceAreaTextBox";
            surfaceAreaTextBox.Size = new Size(100, 23);
            surfaceAreaTextBox.TabIndex = 7;
            // 
            // CalculateButton
            // 
            CalculateButton.Location = new Point(246, 106);
            CalculateButton.Name = "CalculateButton";
            CalculateButton.Size = new Size(122, 23);
            CalculateButton.TabIndex = 8;
            CalculateButton.Text = "Вычислить";
            CalculateButton.UseVisualStyleBackColor = true;
            CalculateButton.Click += CalculateButton_Click;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(617, 141);
            Controls.Add(CalculateButton);
            Controls.Add(surfaceAreaTextBox);
            Controls.Add(label4);
            Controls.Add(volumeTextBox);
            Controls.Add(label3);
            Controls.Add(heightTextBox);
            Controls.Add(label2);
            Controls.Add(radiusTextBox);
            Controls.Add(label1);
            Name = "Form1";
            Text = "Form1";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private TextBox radiusTextBox;
        private Label label2;
        private TextBox heightTextBox;
        private Label label3;
        private TextBox volumeTextBox;
        private Label label4;
        private TextBox surfaceAreaTextBox;
        private Button CalculateButton;
    }
}