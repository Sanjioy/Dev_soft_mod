﻿using System;

namespace Пр7_2_Стынгач
{
    // Класс Avto
    class Avto
    {
        private string brand;
        private string color;
        private int skor;

        public Avto() { }
        public Avto(string brand, string color, int skor)
        {
            this.brand = brand;
            this.color = color;
            this.skor = skor;

        }
        public void ShowInfo()
        {
            Console.WriteLine("Марка {0} цвет {1} скорость {2}", brand, color, skor);
        }
        public string Brand
        {
            get
            {
                return (brand != "") ? brand : "неизвестный";
            }
            set
            {
                brand = value.ToUpper();
            }
        }

        public string Color
        {
            get
            {
                return (color != "") ? color : "неизвестный";
            }
            set
            {
                color = value.ToUpper();
            }
        }

        public int Skor
        {
            get => skor; set
            {
                skor = (value < 20 || value > 120) ? 0 : value;
            }
        }
    }

    // Класс Kadry
    class Kadry
    {
        private string fam;
        private int age;
        private string dol;
        private int staj;

        public Kadry()
        {
        }

        public Kadry(string fam, int age, string dol, int staj)
        {
            Fam = fam;
            Age = age;
            Dol = dol;
            Staj = staj;
        }

        public void ShowInfo()
        {
            Console.WriteLine("Фамилия: {0}, Возраст: {1}, Должность: {2}, Стаж: {3}", Fam, Age, Dol, Staj);
        }

        public string Fam
        {
            get => fam;
            set => fam = value;
        }

        public int Age
        {
            get => age;
            set
            {
                if (value >= 16 && value <= 60)
                {
                    age = value;
                }
                else
                {
                    throw new ArgumentException("Недопустимый возраст");
                }
            }
        }

        public string Dol
        {
            get => dol;
            set => dol = value;
        }

        public int Staj
        {
            get => staj;
            set
            {
                if (value >= 0 && value <= 45)
                {
                    staj = value;
                }
                else
                {
                    throw new ArgumentException("Недопустимый стаж");
                }
            }
        }
    }

    // Класс Computer
    class Computer
    {
        private string model;
        private int ram;
        private int hdd;

        public Computer()
        {
        }

        public Computer(string model, int ram, int hdd)
        {
            Model = model;
            Ram = ram;
            Hdd = hdd;
        }

        public void ShowInfo()
        {
            Console.WriteLine("Модель: {0}, ОЗУ: {1} Гб, Жесткий диск: {2} Гб", Model, Ram, Hdd);
        }

        public string Model
        {
            get => model;
            set => model = value;
        }

        public int Ram
        {
            get => ram;
            set
            {
                if (value >= 2 && value <= 32)
                {
                    ram = value;
                }
                else
                {
                    throw new ArgumentException("Недопустимый объем ОЗУ");
                }
            }
        }

        public int Hdd
        {
            get => hdd;
            set
            {
                if (value >= 200 && value <= 2000)
                {
                    hdd = value;
                }
                else
                {
                    throw new ArgumentException("Недопустимый объем жесткого диска");
                }
            }
        }
    }

    // Класс Tovar
    class Tovar
    {
        private string name;
        private double price;
        private int kvo;

        public Tovar()
        {
        }

        public Tovar(string name, double price, int kvo)
        {
            Name = name;
            Price = price;
            Kvo = kvo;
        }

        public double TotalCost()
        {
            return Price * Kvo;
        }

        public void ShowInfo()
        {
            Console.WriteLine("Товар: {0}, Цена: {1}$, Количество: {2}, Общая стоимость: {3}$",
                              Name, Price, Kvo, TotalCost());
        }

        public string Name
        {
            get => name;
            set => name = value;
        }

        public double Price
        {
            get => price;
            set
            {
                if (value >= 1 && value <= 20)
                {
                    price = value;
                }
                else
                {
                    throw new ArgumentException("Недопустимая цена");
                }
            }
        }

        public int Kvo
        {
            get => kvo;
            set
            {
                if (value >= 0 && value <= 10)
                {
                    kvo = value;
                }
                else
                {
                    throw new ArgumentException("Недопустимое количество");
                }
            }
        }
    }

    // Основной класс
    class Program
    {
        static void Main(string[] args)
        {
            Avto st1 = new Avto("Mercedes", "Green", 110);
            st1.ShowInfo();
            Kadry st2 = new Kadry("Иванов", 25, "Менеджер", 10);
            st2.ShowInfo();
            Computer st3 = new Computer("Lenovo", 16, 500);
            st3.ShowInfo();
            Tovar st4 = new Tovar("Книга", 15, 3);
            st4.ShowInfo();
            Console.ReadKey();
        }
    }
}