﻿using System;

namespace Пр7_1_Стынгач
{
    class Student
    {
        private string fam;
        private string name;
        private int kurs;
        private int age;

        public Student() { }
        public Student(string fam, string name, int kurs, int age)
        {
            this.Fam = fam;
            this.Kurs = kurs;
            this.Age = age;
            this.Name = name;
        }
        public void ShowInfo()
        {
            Console.WriteLine("Студент {0} с именем {1} курса {2} возраста {3}", Fam, Name, Kurs, Age);
        }

        public string Fam
        {
            get
            {
                return (fam != "") ? fam : "неизвестный";
            }
            set
            {
                fam = value.ToUpper();
            }
        }

        public int Kurs
        {
            get => kurs; set
            {
                kurs = (value < 1 || value > 4) ? 0 : value;
            }
        }
        public int Age
        {
            get => age; set
            {
                age = (value < 15 || value > 35) ? 0 : value;
            }
        }
        public string Name
        {
            get
            {
                return (name != "") ? name : "неизвестный";
            }
            set
            {
                name = value.ToUpper();
            }
        }
    }

    class Program
    {
        static void Main()
        {
            Student st1 = new Student("Иванов", "Дима", 1, 25);
            st1.ShowInfo();
            Student st2 = new Student("Шулер", "Макар", 3, 18);
            st2.ShowInfo();
            Student st3 = new Student("Петров", "Петр", 4, 34);
            st3.ShowInfo();
            //Student st4 = new Student("", 2); st4.ShowInfo();
            Console.ReadKey();
        }
    }
}